import Vue from "nativescript-vue";
import Welcome from "./components/Welcome";
import { getString } from 'tns-core-modules/application-settings';
import Vuex from 'vuex';
Vue.use(Vuex);
import store from './store';
const appSettings = require("tns-core-modules/application-settings");
import { TNSFontIcon, fonticon } from './nativescript-fonticon';
TNSFontIcon.debug = true;
TNSFontIcon.paths = {
    'fa': './fonts/font-awesome.css',
    'ion': './fonts/ionicons.css',
};
TNSFontIcon.loadCss();
Vue.filter('fonticon', fonticon);
Vue.registerElement("PreviousNextView", () => require("nativescript-iqkeyboardmanager"). PreviousNextView)
new Vue({
    store,
    created () {
        const userString = appSettings.getString('user'); // grab user data from local storage
        if (userString) { // check to see if there is indeed a user
          const userData = JSON.parse(userString) // parse user data into JSON
          this.$store.commit('SET_USER_DATA', userData) // restore user data with Vuex
        }
      },
    render: h => h('frame', [h(Welcome)])
   
}).$start();

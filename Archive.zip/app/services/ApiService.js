import axios  from "axios";

const apiClient = axios.create({
    baseURL : 'https://api.heloadadisini.com',
    withCredentials: false,
    headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json'
    }
});

export default {
    getMember(id){
        return apiClient.get('/member?id='+id);
    },
    getMembers(){
        return apiClient.get('/member/allMember');
    },
    getMessage(){
        return apiClient.get('/message');
    },
    login(){
        return true;//apiClient.get('/user?act=login&data='+user);
    }
}
 
export declare const mapCss: (data: any, debug?: boolean) => object;
export declare const cleanValue: (val: string) => string | void;

export declare class TNSFontIcon {
    static css: any;
    static paths: any;
    static debug: boolean;
    static loadCss(): Promise<any>;
}
export declare function fonticon(value: string): string;

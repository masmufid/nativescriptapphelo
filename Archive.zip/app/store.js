import Vue from 'nativescript-vue';
import Vuex from 'vuex';
import axios from 'axios';
import { setString,remove } from 'tns-core-modules/application-settings';
Vue.use(Vuex);
const appSettings = require("tns-core-modules/application-settings");
export default new Vuex.Store({
    state: {
        user:null,
        message:"",
        token:""
    },
    mutations: {
        SET_USER_DATA (state, userData){
            state.message = userData.message;
            /*
            appSettings.setString('user', JSON.stringify(userData))
            axios.defaults.headers.common['Authorization'] = `Bearer ${
              userData.jwt
            }`
            */
        },
        SET_USER_LOGIN(state, userData){
            state.message = userData.message;
            appSettings.setString('user',JSON.stringify(userData.data));
            appSettings.setString('token',JSON.stringify(userData.jwt));     
            state.user = userData.data;//appSettings.getString('user');
            state.token = userData.jwt;//appSettings.getString('token');
            
        },
        CLEAR_USER_DATA(state){
            appSettings.remove('user');
            appSettings.remove('token');
            appSettings.clear();
            state.user = null;
            state.message="";
            state.token="";
            
        }
    },
    actions:{
       async register({ commit }, credentials ){
           const { data } = await axios
                .post('https://api.heloadadisini.com/user/register', credentials);
            commit('SET_USER_DATA', data);
       },
       async login({ commit }, credentials ){
           const { data} = await axios
           .post('https://api.heloadadisini.com/user/login', credentials);
           //console.log(data);
           commit('SET_USER_LOGIN', data);
       },
       logout ({ commit }) {
        commit('CLEAR_USER_DATA');
      } 
    }
})

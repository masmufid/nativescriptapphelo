<template>
    <Page class="page">
        <ActionBar  backgroundColor="#ff3300" flat="true"  @tap="logout">
            <Label class="action-bar-title" :text="selectedTab == 0 ? 'Home': judul "></Label>
        </ActionBar>
  <BottomNavigation backgroundColor="#000000">
        <TabStrip>
            <TabStripItem :class="selectedTab==0?'active':''" @tap="home">
                <Image src="~/images/navhome.png"></Image>
                <Label text="Home"></Label>
            </TabStripItem>
            <TabStripItem :class="selectedTab==1?'active':''" @tap="order">
                <Image src="~/images/navorders.png"></Image>
                <Label text="Order"></Label>
            </TabStripItem>
            <TabStripItem :class="selectedTab==2?'active':''" @tap="chat">
                <Image src="~/images/navus.png"></Image>
                <Label text="Chat"></Label>
            </TabStripItem>
            <TabStripItem :class="selectedTab==3?'active':''" @tap="belanjaan">
                <Image src="~/images/navcart.png"></Image>
                <Label text="Belanjaan"></Label>
            </TabStripItem>
            <TabStripItem :class="selectedTab==4?'active':''" @tap="pengaturan">
                <Image src="~/images/navset.png"></Image>
                <Label text="Pengaturan"></Label>
            </TabStripItem>
        </TabStrip>

        <TabContentItem>
            <ScrollView orientation="vertical">
            <GridLayout rows="*,*,*,auto,auto,auto">
              <StackLayout  row="0" paddingLeft="10" paddingRight="10"
                    paddingBottom="25" marginTop="0" backgroundColor="#ff3300" 
                     height="10%" width="100%"
                    stretch="aspectFit" class="album-image">  

              </StackLayout>

                <StackLayout  row="1" paddingLeft="25" paddingRight="25" paddingTop="5"
                    paddingBottom="25" marginTop="-20" backgroundColor="#ffffff" 
                    borderRadius="15" height="10%" width="90%"
                    stretch="aspectFit" class="album-image">
                    <GridLayout columns="*,*,*" rows="*,*,*">
                    <Image col="0" row="0"  src="~/images/location.png" stretch="aspectFit" horizontalAlignment="center" width="100px"></Image>    
                     <Label col="1" row="0" class="font-weight-bold"
                                fontSize="16" color="#525151" text="Majalaya" horizontalAlignment="left" verticalAlignment="center"></Label>
                    <Image col="2" row="0"  src="~/images/logo.png" stretch="aspectFit" horizontalAlignment="center"></Image>    
                     <Image src="~/images/deposit.png" row="1" col="0" stretch="aspectFit"></Image>
                         <Image src="~/images/postpaid.png"  row="1" col="1" stretch="aspectFit"></Image>
                         <Image src="~/images/tariktunai.png"  row="1" col="2" stretch="aspectFit"></Image>
                    <Label col="0" row="2"
                                fontSize="12" color="#525151" text="Tabungan Sampah" textAlignment="center"></Label>
                    <Label col="1" row="2" 
                                fontSize="12" color="#525151" text="Top Up/Setor" textAlignment="center"></Label>
                     <Label col="2" row="2" 
                                fontSize="12" color="#525151" text="Tarik Tunai" textAlignment="center"></Label>            
                    </GridLayout>       
                </StackLayout>
            
               <StackLayout  row="2" paddingLeft="10" paddingRight="10" paddingTop="5"
                    paddingBottom="5" marginTop="10" backgroundColor="#f8f8f8" 
                    borderRadius="15" height="35%" width="90%">
                <GridLayout columns="*,*,*,*" rows="*,*,*,*">
                         <Image src="~/images/pulsa.png" row="0" col="0" stretch="aspectFit"></Image>
                         <Image src="~/images/paketdata.png"  row="0" col="1" stretch="aspectFit"></Image>
                         <Image src="~/images/plnpasca.png"  row="0" col="2" stretch="aspectFit"></Image>
                         <Image src="~/images/postpaid.png"  row="0" col="3" stretch="aspectFit"></Image>
                   <Label col="0" row="1"
                                fontSize="12" color="#525151" text="Pulsa/Voucher" textAlignment="center"></Label>
                    <Label col="1" row="1" 
                                fontSize="12" color="#525151" text="Paket Data" textAlignment="center"></Label>
                     <Label col="2" row="1" 
                                fontSize="12" color="#525151" text="PLN/Token" textAlignment="center"></Label>
                     <Label col="3" row="1" 
                                fontSize="12" color="#525151" text="Pasca Bayar" textAlignment="center"></Label>
                  <Image src="~/images/food.png" row="2" col="0" stretch="aspectFit"></Image>
                         <Image src="~/images/driver.png"  row="2" col="1" stretch="aspectFit"></Image>
                         <Image src="~/images/grosir.png"  row="2" col="2" stretch="aspectFit"></Image>
                         <Image src="~/images/cargo.png"  row="2" col="3" stretch="aspectFit"></Image>
                   <Label col="0" row="3"
                                fontSize="12" color="#525151" text="Food" textAlignment="center"></Label>
                    <Label col="1" row="3" 
                                fontSize="12" color="#525151" text="Driver/Kurir" textAlignment="center"></Label>
                     <Label col="2" row="3" 
                                fontSize="12" color="#525151" text="Grosir" textAlignment="center"></Label>
                     <Label col="3" row="3" 
                                fontSize="12" color="#525151" text="Cargo" textAlignment="center"></Label>
                </GridLayout>
        </StackLayout>
            <StackLayout row="3"  height="35%" paddingLeft="15" paddingRight="15" marginTop="10">		
			
            <ScrollView orientation="horizontal">
    <StackLayout orientation="horizontal">
      <StackLayout>
        <Image src="~/images/bikeday.png" borderRadius="15" height="25%" margin="10" stretch="aspectFit"></Image>
      </StackLayout>  
      <StackLayout>
        <Image src="~/images/sampah.jpg" borderRadius="15" height="25%" margin="10"  stretch="aspectFit"></Image>
      </StackLayout>  
      <StackLayout>
        <Image src="~/images/agenpulsa.jpg" borderRadius="15" height="25%" margin="10"  stretch="aspectFit"></Image>
      </StackLayout>  
      
    </StackLayout>
  </ScrollView> 
			</StackLayout>   
            
            
            </GridLayout>
            </ScrollView>
        </TabContentItem>

        <TabContentItem>
            <StackLayout>
                <Label :text="judul"></Label>
              <Weather />
            </StackLayout>
        </TabContentItem>
        <TabContentItem>
            <StackLayout>
                <Label :text="judul" class="h1 text-center p-t-20"></Label>
                <Label class="fa" textWrap="true">
    <FormattedString>
        <Span text="&#xf041;"></Span>
    </FormattedString>
</Label>
            </StackLayout>
        </TabContentItem>

        <TabContentItem>
            <StackLayout>
                <Label text="Bottom Nav Content 4" class="h1 text-center p-t-20"></Label>
            </StackLayout>
        </TabContentItem>

        <TabContentItem>
            <StackLayout>
                <Label text="Bottom Nav Content 5" class="h1 text-center p-t-20"></Label>
            </StackLayout>
        </TabContentItem>
    </BottomNavigation>


    </Page>
</template>

<script>
    import Login from "./Login";
    import { mapState } from 'vuex';
    import Item from "./custom/item";
    import Category from "./custom/category";
    import Weather from "./Weather";
    export default {
        components: {
        Weather,
		Item,
		Category
	    },
        data() {
            return {
                //message: "Welcome..",
                saldo:0,
                userData:this.$store.state.user,
                selectedTab: 0,
                selectedTabview: 0,
                items: [{
				name: "Manila Ultimate Tombstone Burger",
				cover: "~/assets/images/food/burger640.jpg",
				images: [
						{src: "~/assets/images/food/burger/burger1.jpg"},
						{src: "~/assets/images/food/burger/burger2.jpg"},
						{src: "~/assets/images/food/burger/burger3.jpg"},
						{src: "~/assets/images/food/burger/burger4.jpg"},
						{src: "~/assets/images/food/burger/burger5.jpg"},
						{src: "~/assets/images/food/burger/burger6.jpg"}
					],
				category: "Burger",
				categoryTag: "#2D9CDB",
				price: "300.00",
				likes: 987,
				isLike: false,
				isFavorite: true,
				comments: 13,
				rating: "4.5",
                description: "a",
                judul:"Home"
			},
			{
				name: "Quezon Chocolate Marble Pancake",
				cover: "~/assets/images/food/pancake640.jpg",
				images: [
					{src: "~/assets/images/food/pancake/pancake1.jpg"},
					{src: "~/assets/images/food/pancake/pancake2.jpg"},
					{src: "~/assets/images/food/pancake/pancake3.jpg"},
					{src: "~/assets/images/food/pancake/pancake4.jpg"},
					{src: "~/assets/images/food/pancake/pancake5.jpg"},
					{src: "~/assets/images/food/pancake/pancake6.jpg"}
				],
				category: "Pancake",
				categoryTag: "#e4ce0d",
				price: "230.00",
				likes: 891,
				isLike: true,
				isFavorite: true,
				comments: 7,
				rating: "4.0",
				description: "a"
			},
			{
				name: "Binondo Black Forest Cake",
				cover: "~/assets/images/food/cake640.jpg",
				images: [
					{src: "~/assets/images/food/cake/cake1.jpg"},
					{src: "~/assets/images/food/cake/cake2.jpg"},
					{src: "~/assets/images/food/cake/cake3.jpg"},
					{src: "~/assets/images/food/cake/cake4.jpg"}
				],
				category: "Cake",
				categoryTag: "#27AE60",
				price: "300.00",
				likes: 730,
				isLike: true,
				isFavorite: true,
				comments: 11,
				rating: "4.0",
				description: "a"
			},
			],
			category: [
			{
				cover: "~/assets/images/food/burger640.jpg",
				category: "BURGER",
				count: "13",
			},
			{
				cover: "~/assets/images/food/pancake640.jpg",
				category: "PANCAKE",
				count: "5",
			},
			{
				cover: "~/assets/images/food/cake640.jpg",
				category: "CAKE",
				count: "9",
			},
			{
				cover: "~/assets/images/food/beer640.jpg",
				category: "BEER",
				count: "7",
			},
		
			]
		
            };
        },
        computed:{

            itemsCategory(){
			return this.category.slice().reverse();
		    },
            getSaldo(){
                return this.saldo
            },
            welcome(){
                return "No HP anda " + this.userData.no_hp
            },
            ...mapState(['user','message'])
        },
        methods: {
        logout() {
                this.$store
                    .dispatch('logout')
                    .then(() => {   
                        //this.alert("Sampai jumpa lagi...");  
                        this.$navigateTo(Login, { clearHistory: true });
                    })
        },
        home() {
            this.selectedTab = 0;
            this.judul ='Home';
		},
		order() {
            this.selectedTab = 1;
            this.judul = 'Order';
		},
		chat() {
            this.selectedTab = 2;
            this.judul = 'Chat';
		},
		belanjaan() {
            this.selectedTab = 4;
            this.judul = 'Belanjaan';
        },
        pengaturan() {
            this.selectedTab = 5;
            this.judul = 'Pengaturan'
        }
        
        }
    };
</script>

<style>
    .navBottom {
        background-color: #ff3300;
        border-color: #ff3300;
        color:#ffffff;
    }

ActionBar {
        background-color: transparent;
    }

    .album-image {
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
    }

    .home-panel {
        vertical-align: center;
        font-size: 20;
        margin: 15;
    }

    .description-label {
        margin-bottom: 15;
    }

    #searchRow {
        margin-top: 20;
    }
</style>

<template>
    <Page class="page"  actionBarHidden="true">
       <FlexboxLayout class="page">
        <StackLayout class="form" orientation="vertical"  horizontalAlignment="center" verticalAlignment="center">
            <Image src="~/images/logo.png"  verticalAlignment="center"></Image>
             <Label textWrap="true" text="Selamat Datang" class="h2"  horizontalAlignment="center"/>
             <Label textWrap="true" :text="message"  class="body text-center"/>
             <Label textWrap="true" :text="members"  class="h3" horizontalAlignment="center" />
             <Button class="btn btn-primary -rounded-lg" text="Mulai" @tap="toLogin"></Button>
            
        </StackLayout>
       </FlexboxLayout>
    </Page>
</template>

<script>
import Login from "./Login";
import ApiService from "@/services/ApiService.js";
  export default {
    data(){
      return {
        nmembers:0,
        welcome_message:"",
        infoTitle:"Welcome message"
      }
    },
    computed: {
      message() {
        return this.welcome_message;
      },
      members(){
        return this.nmembers + " member telah bergabung";
      }
    },
    created(){
     
            ApiService.getMembers()
            .then(response => {
                let str = response.data;
                this.nmembers=str.length.toString();
                
            })
            .catch(error => {
               this.alert("Error dari koneksi internet/server. Coba beberapa saat lagi.");
            });
            ApiService.getMessage()
            .then(response => {
              let str = response.data;
              this.welcome_message = str[0].deskripsi;
              console.log(str);
            })
            .catch(error => {
              this.welcome_message = error;
            });
            
    },
    methods:{
      toLogin(){
        this.$navigateTo(Login, { clearHistory: true });
      }
    }
  };
</script>
<style scoped>
.page {
        align-items: center;
        flex-direction: column;
    }
    .form {
        margin-left: 30;
        margin-right: 30;
        flex-grow: 2;
        vertical-align: middle;
    }
</style>

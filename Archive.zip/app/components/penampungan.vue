<GridLayout rows="200 200 200 200 200 200 200 200 200 200">
        <Label class="m-10" row="0" text="Some text content follows here..." textWrap="true"></Label>
        <Label class="m-10" row="1" text="Some text content follows here..." textWrap="true"></Label>
        <Label class="m-10" row="2" text="Some text content follows here..." textWrap="true"></Label>
        <Label class="m-10" row="3" text="Some text content follows here..." textWrap="true"></Label>
        <Label class="m-10" row="4" text="Some text content follows here..." textWrap="true"></Label>
        <Label class="m-10" row="5" text="Some text content follows here..." textWrap="true"></Label>
        <Label class="m-10" row="6" text="Some text content follows here..." textWrap="true"></Label>
        <Label class="m-10" row="7" text="Some text content follows here..." textWrap="true"></Label>
        <Label class="m-10" row="8" text="Some text content follows here..." textWrap="true"></Label>
        <Label class="m-10" row="9" text="Some text content follows here..." textWrap="true"></Label>
    </GridLayout>
    
        <GridLayout orientation="vertical" width="100%" height="100%" columns="*"
            rows="*,auto">

            <StackLayout col="0" row="0" backgroundColor="#f8f8f8">
                <StackLayout backgroundColor="#ff3300" paddingBottom="5"
                    marginTop="-5">
                    <Label text="    Home" class="font-weight-bold"
                        color="#FFFFFF" padding="25" fontSize="24"></Label>
                </StackLayout>

                <StackLayout paddingLeft="10" paddingRight="10" paddingTop="5"
                    paddingBottom="0" marginTop="-50" backgroundColor="#ffffff" 
                    borderRadius="15" height="30%" width="90%"
                    stretch="aspectFit" class="album-image">
                    <GridLayout columns="*,*,100" rows="*,*,*">
                    <Image col="0" row="0"  src="~/images/location.png" stretch="aspectFit" horizontalAlignment="center" width="100px"></Image>    
                    
                     <Label col="1" row="0" class="font-weight-bold"
                                fontSize="16" color="#525151" text="Majalaya" textAlignment="left"></Label>
                    <Image col="2" row="0"  src="~/images/logo.png" stretch="aspectFit" horizontalAlignment="center"></Image>    
                     <Image src="~/images/deposit.png" row="1" col="0" stretch="aspectFit"></Image>
                         <Image src="~/images/postpaid.png"  row="1" col="1" stretch="aspectFit"></Image>
                         <Image src="~/images/tariktunai.png"  row="1" col="2" stretch="aspectFit"></Image>
                    <Label col="0" row="2"
                                fontSize="12" color="#525151" text="Tabungan Sampah" textAlignment="center"></Label>
                    <Label col="1" row="2" 
                                fontSize="12" color="#525151" text="Top Up/Setor" textAlignment="center"></Label>
                     <Label col="2" row="2" 
                                fontSize="12" color="#525151" text="Tarik Tunai" textAlignment="center"></Label>
                                
                    </GridLayout>
                    
                    <!--
                        <GridLayout columns="auto,*" rows="*,*,*"
                            col="0" row="0" marginBottom="100">
                            <Label col="0" row="0" class="font-weight-bold"
                                fontSize="20" color="#525151" text="Saldo"  textAlignment="left"></Label>
                            <Label col="0" row="1" class="font-weight-bold"
                                fontSize="24" color="#525151" text="Rp 500.000,-"></Label>
                            <Label col="1" row="0" class="font-weight-bold"
                                fontSize="16" color="#525151" text="Majalaya City" textAlignment="right"></Label>
                            <Image col="1" row="1" rowSpan="2" src="~/images/logo.png" stretch="aspectFit" horizontalAlignment="right"></Image>    
                        </GridLayout>
                    -->
                </StackLayout>
            </StackLayout>
               <StackLayout paddingLeft="10" paddingRight="10" paddingTop="5"
                    paddingBottom="0" marginTop="5" backgroundColor="#ffffff" 
                    borderRadius="15" height="30%" width="90%">
                <GridLayout columns="*,*,*,*" rows="*,*,*,*">
                         <Image src="~/images/pulsa.png" row="0" col="0" stretch="aspectFit"></Image>
                         <Image src="~/images/paketdata.png"  row="0" col="1" stretch="aspectFit"></Image>
                         <Image src="~/images/plnpasca.png"  row="0" col="2" stretch="aspectFit"></Image>
                         <Image src="~/images/postpaid.png"  row="0" col="3" stretch="aspectFit"></Image>
                   <Label col="0" row="1"
                                fontSize="12" color="#525151" text="Pulsa/Voucher" textAlignment="center"></Label>
                    <Label col="1" row="1" 
                                fontSize="12" color="#525151" text="Paket Data" textAlignment="center"></Label>
                     <Label col="2" row="1" 
                                fontSize="12" color="#525151" text="PLN/Token" textAlignment="center"></Label>
                     <Label col="3" row="1" 
                                fontSize="12" color="#525151" text="Pasca Bayar" textAlignment="center"></Label>
                  <Image src="~/images/food.png" row="2" col="0" stretch="aspectFit"></Image>
                         <Image src="~/images/driver.png"  row="2" col="1" stretch="aspectFit"></Image>
                         <Image src="~/images/grosir.png"  row="2" col="2" stretch="aspectFit"></Image>
                         <Image src="~/images/cargo.png"  row="2" col="3" stretch="aspectFit"></Image>
                   <Label col="0" row="3"
                                fontSize="12" color="#525151" text="Food" textAlignment="center"></Label>
                    <Label col="1" row="3" 
                                fontSize="12" color="#525151" text="Driver/Kurir" textAlignment="center"></Label>
                     <Label col="2" row="3" 
                                fontSize="12" color="#525151" text="Grosir" textAlignment="center"></Label>
                     <Label col="3" row="3" 
                                fontSize="12" color="#525151" text="Cargo" textAlignment="center"></Label>
                </GridLayout>
        </StackLayout>           
       
        </GridLayout>
      
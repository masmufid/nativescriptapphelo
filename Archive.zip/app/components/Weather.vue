<template>
<GridLayout rows="*,auto,*,auto, auto">
  <Image src="https://s7d2.scene7.com/is/image/TWCNews/1031_nc_sunny_weather_2-1" iosOverflowSafeArea="true" stretch="aspectFill" rowSpan="5"></Image>
  <StackLayout row="1" class="text-center">
    <Label text="Jakarta" class="h1" color="#ffffff"></Label>
    <Label text="Cloudy"  class="h2" color="#ffffff"></Label>
    <Label text="33"  class="h1" color="#ffffff"></Label>
  </StackLayout>
  <ScrollView row="3" orientation="horizontal">
    <StackLayout orientation="horizontal">
      <StackLayout style="color: white; margin: 10; font-size: 13;" class="text-center">
        <Label text="Now"></Label>
        <Image src="https://cdn.pixabay.com/photo/2015/12/03/15/43/sun-1075154_960_720.png" height="20" margin="5"></Image>
        <Label text="79"></Label>
      </StackLayout>  
      <StackLayout style="color: white; margin: 10; font-size: 13;" class="text-center">
        <Label text="10am"></Label>
        <Image src="https://cdn.pixabay.com/photo/2015/12/03/15/43/sun-1075154_960_720.png" height="20" margin="5"></Image>
        <Label text="81"></Label>
      </StackLayout>  
    </StackLayout>
  </ScrollView>
</GridLayout>
</template>
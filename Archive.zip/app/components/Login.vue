<template>
    <Page actionBarHidden="true">
        
        <FlexboxLayout class="page">
            <StackLayout class="form">
                <Image class="logo" src="~/images/logo.png"></Image>
                <Label class="header" :text="isTitleLogin ? 'Login' : 'Sign Up'"></Label>
<Label class="page" :text="textObject"></Label>

                <GridLayout rows="auto, auto, auto">
                    
                    <StackLayout row="0" class="input-field">
                        <TextField class="input" hint="No.HP" :isEnabled="!processing"
                            keyboardType="phone" autocorrect="false"
                            autocapitalizationType="none" v-model="no_hp"
                            returnKeyType="next" @returnPress="focusPassword"></TextField>
                        <StackLayout class="hr-light"></StackLayout>
                        <Label class="error" :text="msg_hp"></Label>
                    </StackLayout>

                    <StackLayout row="1" class="input-field">
                        <TextField class="input" ref="password" :isEnabled="!processing"
                            hint="Password" secure="true" v-model="password"
                            returnKeyType="done"
                            ></TextField>
                        <StackLayout class="hr-light"></StackLayout>
                        <Label class="error" :text="msg_pass"></Label>
                    </StackLayout>
                    
                    

                    <ActivityIndicator rowSpan="3" :busy="processing"></ActivityIndicator>
                </GridLayout>

                <Button :text="isLoggingIn ? 'Log In' : 'Daftar'" :isEnabled="!processing"
                    @tap="submit" class="btn btn-primary m-t-20"></Button>
                <Label *v-show="isLoggingIn" text="Lupa password?"
                    class="login-label" @tap="forgotPassword()"></Label>
            </StackLayout>

            <Label class="login-label sign-up-label" @tap="toggleForm">
                <FormattedString>
                    <Span :text="isLoggingIn ? 'Belum punya akses? ' : 'Kembali ke login'"></Span>
                    <Span :text="isLoggingIn ? 'Daftar' : ''" class="bold"></Span>
                </FormattedString>
            </Label>
        </FlexboxLayout>
    </Page>
</template>

<script>
    import Home from "./Home";
    import ApiService from "@/services/ApiService.js";
    export default {
        data() {
            return {
                isLoggingIn: true,
                processing: false,
                no_hp:"",
                password:"",
                isTitleLogin:true,
                textObject:"",
                msg_hp:"",
                msg_pass:"",
                err_hp:"No HP angka antara 10 - 13 digit",
                err_pass:"Saran: min.6 digit kombinasi huruf besar, kecil & angka"
            };
        },
        watch: {
            
            no_hp(value){
                this.no_hp = value;
                this.msg_hp=this.err_hp;
                this.validateHP(value);
            },
            password(value){
                this.password = value;
                this.msg_pass=this.err_pass;
                this.validatePassword(value);
            }
        
        },
        methods: {
            toggleForm() {
                this.isLoggingIn = !this.isLoggingIn;
                this.isTitleLogin = !this.isTitleLogin;
            },
            submit() {
                if (!this.no_hp || !this.password) {
                    this.alert(
                        "Isi no hp dan password."
                    );
                    return;
                }

                this.processing = true;
                if (this.isLoggingIn) {
                    this.login();
                } else {
                    this.register();
                }
            },

            login() {
                if(this.no_hp == '' || this.password ==''){
                    this.alert("Lengkapi no hp dan password anda");
                    this.processing = false;
                }
                
                this.$store
                    .dispatch('login',{
                        no_hp:this.no_hp,
                        password:this.password
                    })
                    .then(() => {
                        
                        //console.log("error"+this.$store.state.message);
                        
                        if(this.$store.state.message !== 'Successfully logged in')
                        {
                            this.alert(this.$store.state.message);
                            this.processing = false;
                        }
                        
                        this.$navigateTo(Home, { clearHistory: true });
                        
                    })
                    .catch((e)=>{
                        if(e){ 
                        this.alert("Cek no hp/password anda");
                        this.processing = false;
                        }
                        //this.$navigateTo(Login, { clearHistory: true });
                    })
                //this.$navigateTo(Home, { clearHistory: true });
            },

            register() {
                if (this.password == '') {
                    this.alert("Masukkan password.");
                    this.processing = false;
                    return;
                }
                this.$store
                    .dispatch('register',{
                        no_hp:this.no_hp,
                        password:this.password
                    })
                    .then(() => {
                       // this.alert("Cek SMS/WA di hp anda");
                        this.$navigateTo(Home, { clearHistory: true });
                    })
               
            },

            forgotPassword() {
                prompt({
                    title: "Lupa Password",
                    message: "Masukkan nomor HP yang anda gunakan untuk mendaftar",
                    inputType: "number",
                    defaultText: "",
                    okButtonText: "Ok",
                    cancelButtonText: "Cancel"
                }).then(data => {
                    if (data.result) {
                        this.$backendService
                            .resetPassword(data.text.trim())
                            .then(() => {
                                this.alert(
                                    "Password berhasil direset. Masukkan kode yang anda terima di HP anda"
                                );
                            })
                            .catch(() => {
                                this.alert(
                                    "Unfortunately, an error occurred resetting your password."
                                );
                            });
                    }
                });
            },

            focusPassword() {
                this.$refs.password.nativeView.focus();
            },
            focusConfirmPassword() {
                if (!this.isLoggingIn) {
                    this.$refs.confirmPassword.nativeView.focus();
                }
            },

            alert(message) {
                return alert({
                    title: "Helo Ada Disini",
                    okButtonText: "OK",
                    message: message
                });
            },
            
            validateHP(value){
                var no_hp = value;
                var number = /^[0-9]+$/;
                
                if(!no_hp.match(number)){
                    this.alert("Nomor HP harus berupa angka!");
                    return false;
                }
                
                if(no_hp.length > 13){
                    this.alert("No HP antara 10 sampai 13 digit");
                    return false;
                }
            },
            validatePassword(value){
                if(this.no_hp.length < 10){
                    this.msg_hp = "No HP tidak boleh kurang dari 10 digit";
                }
            }
            
        }
    };
</script>

<style scoped>
    .error {
        color:red;
    }
    .page {
        align-items: center;
        flex-direction: column;
    }
    .hint-color {
        color:grey;
    }
    .form {
        margin-left: 30;
        margin-right: 30;
        margin-top:40;
        flex-grow: 2;
        vertical-align: top;
    }

    .logo {
        margin-bottom: 12;
        height: 90;
        font-weight: bold;
    }

    .header {
        text-align: center;
        font-size: 25;
        font-weight: 600;
        margin-bottom: 70;
        text-align: center;
        color: #D51A1A;
    }

    .input-field {
        margin-bottom: 25;
    }

    .input {
        font-size: 18;
        
    }

    .input:disabled {
        background-color: white;
        opacity: 0.5;
    }

    .btn-primary {
        margin: 30 5 15 5;
    }

    .login-label {
        text-align: center;
        color: #A8A8A8;
        font-size: 16;
    }

    .sign-up-label {
        margin-bottom: 20;
    }

    .bold {
        color: #000000;
    }
</style>

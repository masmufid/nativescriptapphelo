webpackHotUpdate("bundle",{

/***/ "../node_modules/babel-loader/lib/index.js!../node_modules/vue-loader/lib/index.js?!./components/Home.vue?vue&type=script&lang=js&":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Login__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./components/Login.vue");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("../node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _custom_item__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./components/custom/item.vue");
/* harmony import */ var _custom_category__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./components/custom/category.vue");
/* harmony import */ var _Weather__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./components/Weather.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    Item: _custom_item__WEBPACK_IMPORTED_MODULE_2__["default"],
    Category: _custom_category__WEBPACK_IMPORTED_MODULE_3__["default"]
  },

  data() {
    return {
      //message: "Welcome..",
      saldo: 0,
      userData: this.$store.state.user,
      selectedTab: 0,
      selectedTabview: 0,
      items: [{
        name: "Manila Ultimate Tombstone Burger",
        cover: "~/assets/images/food/burger640.jpg",
        images: [{
          src: "~/assets/images/food/burger/burger1.jpg"
        }, {
          src: "~/assets/images/food/burger/burger2.jpg"
        }, {
          src: "~/assets/images/food/burger/burger3.jpg"
        }, {
          src: "~/assets/images/food/burger/burger4.jpg"
        }, {
          src: "~/assets/images/food/burger/burger5.jpg"
        }, {
          src: "~/assets/images/food/burger/burger6.jpg"
        }],
        category: "Burger",
        categoryTag: "#2D9CDB",
        price: "300.00",
        likes: 987,
        isLike: false,
        isFavorite: true,
        comments: 13,
        rating: "4.5",
        description: "a",
        judul: "Home"
      }, {
        name: "Quezon Chocolate Marble Pancake",
        cover: "~/assets/images/food/pancake640.jpg",
        images: [{
          src: "~/assets/images/food/pancake/pancake1.jpg"
        }, {
          src: "~/assets/images/food/pancake/pancake2.jpg"
        }, {
          src: "~/assets/images/food/pancake/pancake3.jpg"
        }, {
          src: "~/assets/images/food/pancake/pancake4.jpg"
        }, {
          src: "~/assets/images/food/pancake/pancake5.jpg"
        }, {
          src: "~/assets/images/food/pancake/pancake6.jpg"
        }],
        category: "Pancake",
        categoryTag: "#e4ce0d",
        price: "230.00",
        likes: 891,
        isLike: true,
        isFavorite: true,
        comments: 7,
        rating: "4.0",
        description: "a"
      }, {
        name: "Binondo Black Forest Cake",
        cover: "~/assets/images/food/cake640.jpg",
        images: [{
          src: "~/assets/images/food/cake/cake1.jpg"
        }, {
          src: "~/assets/images/food/cake/cake2.jpg"
        }, {
          src: "~/assets/images/food/cake/cake3.jpg"
        }, {
          src: "~/assets/images/food/cake/cake4.jpg"
        }],
        category: "Cake",
        categoryTag: "#27AE60",
        price: "300.00",
        likes: 730,
        isLike: true,
        isFavorite: true,
        comments: 11,
        rating: "4.0",
        description: "a"
      }],
      category: [{
        cover: "~/assets/images/food/burger640.jpg",
        category: "BURGER",
        count: "13"
      }, {
        cover: "~/assets/images/food/pancake640.jpg",
        category: "PANCAKE",
        count: "5"
      }, {
        cover: "~/assets/images/food/cake640.jpg",
        category: "CAKE",
        count: "9"
      }, {
        cover: "~/assets/images/food/beer640.jpg",
        category: "BEER",
        count: "7"
      }]
    };
  },

  computed: {
    itemsCategory() {
      return this.category.slice().reverse();
    },

    getSaldo() {
      return this.saldo;
    },

    welcome() {
      return "No HP anda " + this.userData.no_hp;
    },

    ...Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapState"])(['user', 'message'])
  },
  methods: {
    logout() {
      this.$store.dispatch('logout').then(() => {
        //this.alert("Sampai jumpa lagi...");  
        this.$navigateTo(_Login__WEBPACK_IMPORTED_MODULE_0__["default"], {
          clearHistory: true
        });
      });
    },

    home() {
      this.selectedTab = 0;
      this.judul = 'Home';
    },

    order() {
      this.selectedTab = 1;
      this.judul = 'Order';
    },

    chat() {
      this.selectedTab = 2;
      this.judul = 'Chat';
    },

    belanjaan() {
      this.selectedTab = 4;
      this.judul = 'Belanjaan';
    },

    pengaturan() {
      this.selectedTab = 5;
      this.judul = 'Pengaturan';
    }

  }
});

/***/ }),

/***/ "../node_modules/vue-loader/lib/loaders/templateLoader.js?!../node_modules/vue-loader/lib/index.js?!./components/Weather.vue?vue&type=template&id=0716132e&":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "GridLayout",
    { attrs: { rows: "*,auto,*,auto, auto" } },
    [
      _c("Image", {
        attrs: {
          src:
            "https://s7d2.scene7.com/is/image/TWCNews/1031_nc_sunny_weather_2-1",
          iosOverflowSafeArea: "true",
          stretch: "aspectFill",
          rowSpan: "5"
        }
      }),
      _c(
        "StackLayout",
        { staticClass: "text-center", attrs: { row: "1" } },
        [
          _c("Label", {
            staticClass: "h1",
            attrs: { text: "Jakarta", color: "#ffffff" }
          }),
          _c("Label", {
            staticClass: "h2",
            attrs: { text: "Cloudy", color: "#ffffff" }
          }),
          _c("Label", {
            staticClass: "h1",
            attrs: { text: "33", color: "#ffffff" }
          })
        ],
        1
      ),
      _c(
        "ScrollView",
        { attrs: { row: "3", orientation: "horizontal" } },
        [
          _c(
            "StackLayout",
            { attrs: { orientation: "horizontal" } },
            [
              _c(
                "StackLayout",
                {
                  staticClass: "text-center",
                  staticStyle: { color: "white", margin: "10", fontSize: "13" }
                },
                [
                  _c("Label", { attrs: { text: "Now" } }),
                  _c("Image", {
                    attrs: {
                      src:
                        "https://cdn.pixabay.com/photo/2015/12/03/15/43/sun-1075154_960_720.png",
                      height: "20",
                      margin: "5"
                    }
                  }),
                  _c("Label", { attrs: { text: "79" } })
                ],
                1
              ),
              _c(
                "StackLayout",
                {
                  staticClass: "text-center",
                  staticStyle: { color: "white", margin: "10", fontSize: "13" }
                },
                [
                  _c("Label", { attrs: { text: "10am" } }),
                  _c("Image", {
                    attrs: {
                      src:
                        "https://cdn.pixabay.com/photo/2015/12/03/15/43/sun-1075154_960_720.png",
                      height: "20",
                      margin: "5"
                    }
                  }),
                  _c("Label", { attrs: { text: "81" } })
                ],
                1
              )
            ],
            1
          )
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./components/Weather.vue":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Weather_vue_vue_type_template_id_0716132e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./components/Weather.vue?vue&type=template&id=0716132e&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("../node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _Weather_vue_vue_type_template_id_0716132e___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Weather_vue_vue_type_template_id_0716132e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (true) {
  var api = __webpack_require__("../node_modules/vue-hot-reload-api/dist/index.js")
  api.install(__webpack_require__("../node_modules/nativescript-vue/dist/index.js"))
  if (api.compatible) {
    module.hot.accept()
    if (!module.hot.data) {
      api.createRecord('0716132e', component.options)
    } else {
      api.reload('0716132e', component.options)
    }
    module.hot.accept("./components/Weather.vue?vue&type=template&id=0716132e&", function(__WEBPACK_OUTDATED_DEPENDENCIES__) { /* harmony import */ _Weather_vue_vue_type_template_id_0716132e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./components/Weather.vue?vue&type=template&id=0716132e&");
(function () {
      api.rerender('0716132e', {
        render: _Weather_vue_vue_type_template_id_0716132e___WEBPACK_IMPORTED_MODULE_0__["render"],
        staticRenderFns: _Weather_vue_vue_type_template_id_0716132e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]
      })
    })(__WEBPACK_OUTDATED_DEPENDENCIES__); })
  }
}
component.options.__file = "components/Weather.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./components/Weather.vue?vue&type=template&id=0716132e&":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Weather_vue_vue_type_template_id_0716132e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/vue-loader/lib/loaders/templateLoader.js?!../node_modules/vue-loader/lib/index.js?!./components/Weather.vue?vue&type=template&id=0716132e&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Weather_vue_vue_type_template_id_0716132e___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Weather_vue_vue_type_template_id_0716132e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vY29tcG9uZW50cy9Ib21lLnZ1ZSIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL1dlYXRoZXIudnVlPzNhYzIiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9XZWF0aGVyLnZ1ZSIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL1dlYXRoZXIudnVlP2Q3ZWQiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFtSkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4REFEQTtBQUVBO0FBRkEsR0FEQTs7QUFLQTtBQUNBO0FBQ0E7QUFDQSxjQUZBO0FBR0Esc0NBSEE7QUFJQSxvQkFKQTtBQUtBLHdCQUxBO0FBTUE7QUFDQSxnREFEQTtBQUVBLG1EQUZBO0FBR0EsaUJBQ0E7QUFBQTtBQUFBLFNBREEsRUFFQTtBQUFBO0FBQUEsU0FGQSxFQUdBO0FBQUE7QUFBQSxTQUhBLEVBSUE7QUFBQTtBQUFBLFNBSkEsRUFLQTtBQUFBO0FBQUEsU0FMQSxFQU1BO0FBQUE7QUFBQSxTQU5BLENBSEE7QUFXQSwwQkFYQTtBQVlBLDhCQVpBO0FBYUEsdUJBYkE7QUFjQSxrQkFkQTtBQWVBLHFCQWZBO0FBZ0JBLHdCQWhCQTtBQWlCQSxvQkFqQkE7QUFrQkEscUJBbEJBO0FBbUJBLHdCQW5CQTtBQW9CQTtBQXBCQSxTQXNCQTtBQUNBLCtDQURBO0FBRUEsb0RBRkE7QUFHQSxpQkFDQTtBQUFBO0FBQUEsU0FEQSxFQUVBO0FBQUE7QUFBQSxTQUZBLEVBR0E7QUFBQTtBQUFBLFNBSEEsRUFJQTtBQUFBO0FBQUEsU0FKQSxFQUtBO0FBQUE7QUFBQSxTQUxBLEVBTUE7QUFBQTtBQUFBLFNBTkEsQ0FIQTtBQVdBLDJCQVhBO0FBWUEsOEJBWkE7QUFhQSx1QkFiQTtBQWNBLGtCQWRBO0FBZUEsb0JBZkE7QUFnQkEsd0JBaEJBO0FBaUJBLG1CQWpCQTtBQWtCQSxxQkFsQkE7QUFtQkE7QUFuQkEsT0F0QkEsRUEyQ0E7QUFDQSx5Q0FEQTtBQUVBLGlEQUZBO0FBR0EsaUJBQ0E7QUFBQTtBQUFBLFNBREEsRUFFQTtBQUFBO0FBQUEsU0FGQSxFQUdBO0FBQUE7QUFBQSxTQUhBLEVBSUE7QUFBQTtBQUFBLFNBSkEsQ0FIQTtBQVNBLHdCQVRBO0FBVUEsOEJBVkE7QUFXQSx1QkFYQTtBQVlBLGtCQVpBO0FBYUEsb0JBYkE7QUFjQSx3QkFkQTtBQWVBLG9CQWZBO0FBZ0JBLHFCQWhCQTtBQWlCQTtBQWpCQSxPQTNDQSxDQU5BO0FBcUVBLGlCQUNBO0FBQ0EsbURBREE7QUFFQSwwQkFGQTtBQUdBO0FBSEEsT0FEQSxFQU1BO0FBQ0Esb0RBREE7QUFFQSwyQkFGQTtBQUdBO0FBSEEsT0FOQSxFQVdBO0FBQ0EsaURBREE7QUFFQSx3QkFGQTtBQUdBO0FBSEEsT0FYQSxFQWdCQTtBQUNBLGlEQURBO0FBRUEsd0JBRkE7QUFHQTtBQUhBLE9BaEJBO0FBckVBO0FBOEZBLEdBcEdBOztBQXFHQTtBQUVBO0FBQ0E7QUFDQSxLQUpBOztBQUtBO0FBQ0E7QUFDQSxLQVBBOztBQVFBO0FBQ0E7QUFDQSxLQVZBOztBQVdBO0FBWEEsR0FyR0E7QUFrSEE7QUFDQTtBQUNBLGtCQUNBLFFBREEsQ0FDQSxRQURBLEVBRUEsSUFGQSxDQUVBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFDQSxPQUxBO0FBTUEsS0FSQTs7QUFTQTtBQUNBO0FBQ0E7QUFDQSxLQVpBOztBQWFBO0FBQ0E7QUFDQTtBQUNBLEtBaEJBOztBQWlCQTtBQUNBO0FBQ0E7QUFDQSxLQXBCQTs7QUFxQkE7QUFDQTtBQUNBO0FBQ0EsS0F4QkE7O0FBeUJBO0FBQ0E7QUFDQTtBQUNBOztBQTVCQTtBQWxIQSxHOzs7Ozs7OztBQ3hKQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLLFNBQVMsOEJBQThCLEVBQUU7QUFDOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQSxTQUFTLHFDQUFxQyxXQUFXLEVBQUU7QUFDM0Q7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CO0FBQ3BCLFdBQVc7QUFDWDtBQUNBO0FBQ0Esb0JBQW9CO0FBQ3BCLFdBQVc7QUFDWDtBQUNBO0FBQ0Esb0JBQW9CO0FBQ3BCLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUyxTQUFTLHNDQUFzQyxFQUFFO0FBQzFEO0FBQ0E7QUFDQTtBQUNBLGFBQWEsU0FBUyw0QkFBNEIsRUFBRTtBQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDO0FBQ2hDLGlCQUFpQjtBQUNqQjtBQUNBLCtCQUErQixTQUFTLGNBQWMsRUFBRTtBQUN4RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQjtBQUNuQiwrQkFBK0IsU0FBUyxhQUFhLEVBQUU7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0M7QUFDaEMsaUJBQWlCO0FBQ2pCO0FBQ0EsK0JBQStCLFNBQVMsZUFBZSxFQUFFO0FBQ3pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CO0FBQ25CLCtCQUErQixTQUFTLGFBQWEsRUFBRTtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7QUMvRkE7QUFBQTtBQUFBO0FBQXNGO0FBQ3RGOzs7QUFHQTtBQUMwRjtBQUMxRixnQkFBZ0IsMkdBQVU7QUFDMUI7QUFDQSxFQUFFLGtGQUFNO0FBQ1IsRUFBRSwyRkFBZTtBQUNqQjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBLElBQUksSUFBVTtBQUNkLFlBQVksbUJBQU8sQ0FBQyxrREFBNEU7QUFDaEcsY0FBYyxtQkFBTyxDQUFDLGdEQUFLO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxzQkFBc0IseURBQThDLEVBQUU7QUFBQTtBQUN0RTtBQUNBLGdCQUFnQixrRkFBTTtBQUN0Qix5QkFBeUIsMkZBQWU7QUFDeEMsT0FBTztBQUNQLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDZSxnRjs7Ozs7Ozs7QUNyQ2Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBIiwiZmlsZSI6ImJ1bmRsZS45NGE5YzYwMjBjZWFjMjdhNjIxZi5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiPHRlbXBsYXRlPlxyXG4gICAgPFBhZ2UgY2xhc3M9XCJwYWdlXCI+XHJcbiAgICAgICAgPEFjdGlvbkJhciAgYmFja2dyb3VuZENvbG9yPVwiI2ZmMzMwMFwiIGZsYXQ9XCJ0cnVlXCIgIEB0YXA9XCJsb2dvdXRcIj5cclxuICAgICAgICAgICAgPExhYmVsIGNsYXNzPVwiYWN0aW9uLWJhci10aXRsZVwiIDp0ZXh0PVwic2VsZWN0ZWRUYWI9PTA/J0hvbWUnOiBqdWR1bCBcIj48L0xhYmVsPlxyXG4gICAgICAgIDwvQWN0aW9uQmFyPlxyXG4gIDxCb3R0b21OYXZpZ2F0aW9uIGJhY2tncm91bmRDb2xvcj1cIiMwMDAwMDBcIj5cclxuICAgICAgICA8VGFiU3RyaXA+XHJcbiAgICAgICAgICAgIDxUYWJTdHJpcEl0ZW0gOmNsYXNzPVwic2VsZWN0ZWRUYWI9PTA/J2FjdGl2ZSc6JydcIiBAdGFwPVwiaG9tZVwiPlxyXG4gICAgICAgICAgICAgICAgPEltYWdlIHNyYz1cIn4vaW1hZ2VzL25hdmhvbWUucG5nXCI+PC9JbWFnZT5cclxuICAgICAgICAgICAgICAgIDxMYWJlbCB0ZXh0PVwiSG9tZVwiPjwvTGFiZWw+XHJcbiAgICAgICAgICAgIDwvVGFiU3RyaXBJdGVtPlxyXG4gICAgICAgICAgICA8VGFiU3RyaXBJdGVtIDpjbGFzcz1cInNlbGVjdGVkVGFiPT0xPydhY3RpdmUnOicnXCIgQHRhcD1cIm9yZGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwifi9pbWFnZXMvbmF2b3JkZXJzLnBuZ1wiPjwvSW1hZ2U+XHJcbiAgICAgICAgICAgICAgICA8TGFiZWwgdGV4dD1cIk9yZGVyXCI+PC9MYWJlbD5cclxuICAgICAgICAgICAgPC9UYWJTdHJpcEl0ZW0+XHJcbiAgICAgICAgICAgIDxUYWJTdHJpcEl0ZW0gOmNsYXNzPVwic2VsZWN0ZWRUYWI9PTI/J2FjdGl2ZSc6JydcIiBAdGFwPVwiY2hhdFwiPlxyXG4gICAgICAgICAgICAgICAgPEltYWdlIHNyYz1cIn4vaW1hZ2VzL25hdnVzLnBuZ1wiPjwvSW1hZ2U+XHJcbiAgICAgICAgICAgICAgICA8TGFiZWwgdGV4dD1cIkNoYXRcIj48L0xhYmVsPlxyXG4gICAgICAgICAgICA8L1RhYlN0cmlwSXRlbT5cclxuICAgICAgICAgICAgPFRhYlN0cmlwSXRlbSA6Y2xhc3M9XCJzZWxlY3RlZFRhYj09Mz8nYWN0aXZlJzonJ1wiIEB0YXA9XCJiZWxhbmphYW5cIj5cclxuICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9XCJ+L2ltYWdlcy9uYXZjYXJ0LnBuZ1wiPjwvSW1hZ2U+XHJcbiAgICAgICAgICAgICAgICA8TGFiZWwgdGV4dD1cIkJlbGFuamFhblwiPjwvTGFiZWw+XHJcbiAgICAgICAgICAgIDwvVGFiU3RyaXBJdGVtPlxyXG4gICAgICAgICAgICA8VGFiU3RyaXBJdGVtIDpjbGFzcz1cInNlbGVjdGVkVGFiPT00PydhY3RpdmUnOicnXCIgQHRhcD1cInBlbmdhdHVyYW5cIj5cclxuICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9XCJ+L2ltYWdlcy9uYXZzZXQucG5nXCI+PC9JbWFnZT5cclxuICAgICAgICAgICAgICAgIDxMYWJlbCB0ZXh0PVwiUGVuZ2F0dXJhblwiPjwvTGFiZWw+XHJcbiAgICAgICAgICAgIDwvVGFiU3RyaXBJdGVtPlxyXG4gICAgICAgIDwvVGFiU3RyaXA+XHJcblxyXG4gICAgICAgIDxUYWJDb250ZW50SXRlbT5cclxuICAgICAgICAgICAgPFNjcm9sbFZpZXcgb3JpZW50YXRpb249XCJ2ZXJ0aWNhbFwiPlxyXG4gICAgICAgICAgICA8R3JpZExheW91dCByb3dzPVwiKiwqLCosYXV0byxhdXRvLGF1dG9cIj5cclxuICAgICAgICAgICAgICA8U3RhY2tMYXlvdXQgIHJvdz1cIjBcIiBwYWRkaW5nTGVmdD1cIjEwXCIgcGFkZGluZ1JpZ2h0PVwiMTBcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmdCb3R0b209XCIyNVwiIG1hcmdpblRvcD1cIjBcIiBiYWNrZ3JvdW5kQ29sb3I9XCIjZmYzMzAwXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgIGhlaWdodD1cIjEwJVwiIHdpZHRoPVwiMTAwJVwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3RyZXRjaD1cImFzcGVjdEZpdFwiIGNsYXNzPVwiYWxidW0taW1hZ2VcIj4gIFxyXG5cclxuICAgICAgICAgICAgICA8L1N0YWNrTGF5b3V0PlxyXG5cclxuICAgICAgICAgICAgICAgIDxTdGFja0xheW91dCAgcm93PVwiMVwiIHBhZGRpbmdMZWZ0PVwiMjVcIiBwYWRkaW5nUmlnaHQ9XCIyNVwiIHBhZGRpbmdUb3A9XCI1XCJcclxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nQm90dG9tPVwiMjVcIiBtYXJnaW5Ub3A9XCItMjBcIiBiYWNrZ3JvdW5kQ29sb3I9XCIjZmZmZmZmXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzPVwiMTVcIiBoZWlnaHQ9XCIxMCVcIiB3aWR0aD1cIjkwJVwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3RyZXRjaD1cImFzcGVjdEZpdFwiIGNsYXNzPVwiYWxidW0taW1hZ2VcIj5cclxuICAgICAgICAgICAgICAgICAgICA8R3JpZExheW91dCBjb2x1bW5zPVwiKiwqLCpcIiByb3dzPVwiKiwqLCpcIj5cclxuICAgICAgICAgICAgICAgICAgICA8SW1hZ2UgY29sPVwiMFwiIHJvdz1cIjBcIiAgc3JjPVwifi9pbWFnZXMvbG9jYXRpb24ucG5nXCIgc3RyZXRjaD1cImFzcGVjdEZpdFwiIGhvcml6b250YWxBbGlnbm1lbnQ9XCJjZW50ZXJcIiB3aWR0aD1cIjEwMHB4XCI+PC9JbWFnZT4gICAgXHJcbiAgICAgICAgICAgICAgICAgICAgIDxMYWJlbCBjb2w9XCIxXCIgcm93PVwiMFwiIGNsYXNzPVwiZm9udC13ZWlnaHQtYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCIxNlwiIGNvbG9yPVwiIzUyNTE1MVwiIHRleHQ9XCJNYWphbGF5YVwiIGhvcml6b250YWxBbGlnbm1lbnQ9XCJsZWZ0XCIgdmVydGljYWxBbGlnbm1lbnQ9XCJjZW50ZXJcIj48L0xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbWFnZSBjb2w9XCIyXCIgcm93PVwiMFwiICBzcmM9XCJ+L2ltYWdlcy9sb2dvLnBuZ1wiIHN0cmV0Y2g9XCJhc3BlY3RGaXRcIiBob3Jpem9udGFsQWxpZ25tZW50PVwiY2VudGVyXCI+PC9JbWFnZT4gICAgXHJcbiAgICAgICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9XCJ+L2ltYWdlcy9kZXBvc2l0LnBuZ1wiIHJvdz1cIjFcIiBjb2w9XCIwXCIgc3RyZXRjaD1cImFzcGVjdEZpdFwiPjwvSW1hZ2U+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwifi9pbWFnZXMvcG9zdHBhaWQucG5nXCIgIHJvdz1cIjFcIiBjb2w9XCIxXCIgc3RyZXRjaD1cImFzcGVjdEZpdFwiPjwvSW1hZ2U+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwifi9pbWFnZXMvdGFyaWt0dW5haS5wbmdcIiAgcm93PVwiMVwiIGNvbD1cIjJcIiBzdHJldGNoPVwiYXNwZWN0Rml0XCI+PC9JbWFnZT5cclxuICAgICAgICAgICAgICAgICAgICA8TGFiZWwgY29sPVwiMFwiIHJvdz1cIjJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiMTJcIiBjb2xvcj1cIiM1MjUxNTFcIiB0ZXh0PVwiVGFidW5nYW4gU2FtcGFoXCIgdGV4dEFsaWdubWVudD1cImNlbnRlclwiPjwvTGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPExhYmVsIGNvbD1cIjFcIiByb3c9XCIyXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCIxMlwiIGNvbG9yPVwiIzUyNTE1MVwiIHRleHQ9XCJUb3AgVXAvU2V0b3JcIiB0ZXh0QWxpZ25tZW50PVwiY2VudGVyXCI+PC9MYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgPExhYmVsIGNvbD1cIjJcIiByb3c9XCIyXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCIxMlwiIGNvbG9yPVwiIzUyNTE1MVwiIHRleHQ9XCJUYXJpayBUdW5haVwiIHRleHRBbGlnbm1lbnQ9XCJjZW50ZXJcIj48L0xhYmVsPiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDwvR3JpZExheW91dD4gICAgICAgXHJcbiAgICAgICAgICAgICAgICA8L1N0YWNrTGF5b3V0PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgPFN0YWNrTGF5b3V0ICByb3c9XCIyXCIgcGFkZGluZ0xlZnQ9XCIxMFwiIHBhZGRpbmdSaWdodD1cIjEwXCIgcGFkZGluZ1RvcD1cIjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmdCb3R0b209XCI1XCIgbWFyZ2luVG9wPVwiMTBcIiBiYWNrZ3JvdW5kQ29sb3I9XCIjZjhmOGY4XCIgXHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzPVwiMTVcIiBoZWlnaHQ9XCIzNSVcIiB3aWR0aD1cIjkwJVwiPlxyXG4gICAgICAgICAgICAgICAgPEdyaWRMYXlvdXQgY29sdW1ucz1cIiosKiwqLCpcIiByb3dzPVwiKiwqLCosKlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgPEltYWdlIHNyYz1cIn4vaW1hZ2VzL3B1bHNhLnBuZ1wiIHJvdz1cIjBcIiBjb2w9XCIwXCIgc3RyZXRjaD1cImFzcGVjdEZpdFwiPjwvSW1hZ2U+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwifi9pbWFnZXMvcGFrZXRkYXRhLnBuZ1wiICByb3c9XCIwXCIgY29sPVwiMVwiIHN0cmV0Y2g9XCJhc3BlY3RGaXRcIj48L0ltYWdlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgPEltYWdlIHNyYz1cIn4vaW1hZ2VzL3BsbnBhc2NhLnBuZ1wiICByb3c9XCIwXCIgY29sPVwiMlwiIHN0cmV0Y2g9XCJhc3BlY3RGaXRcIj48L0ltYWdlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgPEltYWdlIHNyYz1cIn4vaW1hZ2VzL3Bvc3RwYWlkLnBuZ1wiICByb3c9XCIwXCIgY29sPVwiM1wiIHN0cmV0Y2g9XCJhc3BlY3RGaXRcIj48L0ltYWdlPlxyXG4gICAgICAgICAgICAgICAgICAgPExhYmVsIGNvbD1cIjBcIiByb3c9XCIxXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cIjEyXCIgY29sb3I9XCIjNTI1MTUxXCIgdGV4dD1cIlB1bHNhL1ZvdWNoZXJcIiB0ZXh0QWxpZ25tZW50PVwiY2VudGVyXCI+PC9MYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8TGFiZWwgY29sPVwiMVwiIHJvdz1cIjFcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cIjEyXCIgY29sb3I9XCIjNTI1MTUxXCIgdGV4dD1cIlBha2V0IERhdGFcIiB0ZXh0QWxpZ25tZW50PVwiY2VudGVyXCI+PC9MYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgPExhYmVsIGNvbD1cIjJcIiByb3c9XCIxXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCIxMlwiIGNvbG9yPVwiIzUyNTE1MVwiIHRleHQ9XCJQTE4vVG9rZW5cIiB0ZXh0QWxpZ25tZW50PVwiY2VudGVyXCI+PC9MYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgPExhYmVsIGNvbD1cIjNcIiByb3c9XCIxXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCIxMlwiIGNvbG9yPVwiIzUyNTE1MVwiIHRleHQ9XCJQYXNjYSBCYXlhclwiIHRleHRBbGlnbm1lbnQ9XCJjZW50ZXJcIj48L0xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwifi9pbWFnZXMvZm9vZC5wbmdcIiByb3c9XCIyXCIgY29sPVwiMFwiIHN0cmV0Y2g9XCJhc3BlY3RGaXRcIj48L0ltYWdlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgPEltYWdlIHNyYz1cIn4vaW1hZ2VzL2RyaXZlci5wbmdcIiAgcm93PVwiMlwiIGNvbD1cIjFcIiBzdHJldGNoPVwiYXNwZWN0Rml0XCI+PC9JbWFnZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9XCJ+L2ltYWdlcy9ncm9zaXIucG5nXCIgIHJvdz1cIjJcIiBjb2w9XCIyXCIgc3RyZXRjaD1cImFzcGVjdEZpdFwiPjwvSW1hZ2U+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwifi9pbWFnZXMvY2FyZ28ucG5nXCIgIHJvdz1cIjJcIiBjb2w9XCIzXCIgc3RyZXRjaD1cImFzcGVjdEZpdFwiPjwvSW1hZ2U+XHJcbiAgICAgICAgICAgICAgICAgICA8TGFiZWwgY29sPVwiMFwiIHJvdz1cIjNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiMTJcIiBjb2xvcj1cIiM1MjUxNTFcIiB0ZXh0PVwiRm9vZFwiIHRleHRBbGlnbm1lbnQ9XCJjZW50ZXJcIj48L0xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxMYWJlbCBjb2w9XCIxXCIgcm93PVwiM1wiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiMTJcIiBjb2xvcj1cIiM1MjUxNTFcIiB0ZXh0PVwiRHJpdmVyL0t1cmlyXCIgdGV4dEFsaWdubWVudD1cImNlbnRlclwiPjwvTGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgIDxMYWJlbCBjb2w9XCIyXCIgcm93PVwiM1wiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiMTJcIiBjb2xvcj1cIiM1MjUxNTFcIiB0ZXh0PVwiR3Jvc2lyXCIgdGV4dEFsaWdubWVudD1cImNlbnRlclwiPjwvTGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgIDxMYWJlbCBjb2w9XCIzXCIgcm93PVwiM1wiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiMTJcIiBjb2xvcj1cIiM1MjUxNTFcIiB0ZXh0PVwiQ2FyZ29cIiB0ZXh0QWxpZ25tZW50PVwiY2VudGVyXCI+PC9MYWJlbD5cclxuICAgICAgICAgICAgICAgIDwvR3JpZExheW91dD5cclxuICAgICAgICA8L1N0YWNrTGF5b3V0PlxyXG4gICAgICAgICAgICA8U3RhY2tMYXlvdXQgcm93PVwiM1wiICBoZWlnaHQ9XCIzNSVcIiBwYWRkaW5nTGVmdD1cIjE1XCIgcGFkZGluZ1JpZ2h0PVwiMTVcIiBtYXJnaW5Ub3A9XCIxMFwiPlx0XHRcclxuXHRcdFx0XHJcbiAgICAgICAgICAgIDxTY3JvbGxWaWV3IG9yaWVudGF0aW9uPVwiaG9yaXpvbnRhbFwiPlxyXG4gICAgPFN0YWNrTGF5b3V0IG9yaWVudGF0aW9uPVwiaG9yaXpvbnRhbFwiPlxyXG4gICAgICA8U3RhY2tMYXlvdXQ+XHJcbiAgICAgICAgPEltYWdlIHNyYz1cIn4vaW1hZ2VzL2Jpa2VkYXkucG5nXCIgYm9yZGVyUmFkaXVzPVwiMTVcIiBoZWlnaHQ9XCIyNSVcIiBtYXJnaW49XCIxMFwiIHN0cmV0Y2g9XCJhc3BlY3RGaXRcIj48L0ltYWdlPlxyXG4gICAgICA8L1N0YWNrTGF5b3V0PiAgXHJcbiAgICAgIDxTdGFja0xheW91dD5cclxuICAgICAgICA8SW1hZ2Ugc3JjPVwifi9pbWFnZXMvc2FtcGFoLmpwZ1wiIGJvcmRlclJhZGl1cz1cIjE1XCIgaGVpZ2h0PVwiMjUlXCIgbWFyZ2luPVwiMTBcIiAgc3RyZXRjaD1cImFzcGVjdEZpdFwiPjwvSW1hZ2U+XHJcbiAgICAgIDwvU3RhY2tMYXlvdXQ+ICBcclxuICAgICAgPFN0YWNrTGF5b3V0PlxyXG4gICAgICAgIDxJbWFnZSBzcmM9XCJ+L2ltYWdlcy9hZ2VucHVsc2EuanBnXCIgYm9yZGVyUmFkaXVzPVwiMTVcIiBoZWlnaHQ9XCIyNSVcIiBtYXJnaW49XCIxMFwiICBzdHJldGNoPVwiYXNwZWN0Rml0XCI+PC9JbWFnZT5cclxuICAgICAgPC9TdGFja0xheW91dD4gIFxyXG4gICAgICBcclxuICAgIDwvU3RhY2tMYXlvdXQ+XHJcbiAgPC9TY3JvbGxWaWV3PiBcclxuXHRcdFx0PC9TdGFja0xheW91dD4gICBcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8L0dyaWRMYXlvdXQ+XHJcbiAgICAgICAgICAgIDwvU2Nyb2xsVmlldz5cclxuICAgICAgICA8L1RhYkNvbnRlbnRJdGVtPlxyXG5cclxuICAgICAgICA8VGFiQ29udGVudEl0ZW0+XHJcbiAgICAgICAgICAgIDxTdGFja0xheW91dD5cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgPC9TdGFja0xheW91dD5cclxuICAgICAgICA8L1RhYkNvbnRlbnRJdGVtPlxyXG4gICAgICAgIDxUYWJDb250ZW50SXRlbT5cclxuICAgICAgICAgICAgPFN0YWNrTGF5b3V0PlxyXG4gICAgICAgICAgICAgICAgPExhYmVsIHRleHQ9XCJCb3R0b20gTmF2IENvbnRlbnQgM1wiIGNsYXNzPVwiaDEgdGV4dC1jZW50ZXIgcC10LTIwXCI+PC9MYWJlbD5cclxuICAgICAgICAgICAgICAgIDxMYWJlbCBjbGFzcz1cImZhc1wiIHRleHRXcmFwPVwidHJ1ZVwiPlxyXG4gICAgPEZvcm1hdHRlZFN0cmluZz5cclxuICAgICAgICA8U3BhbiB0ZXh0PVwiJiN4ZjA0MTtcIj48L1NwYW4+XHJcbiAgICA8L0Zvcm1hdHRlZFN0cmluZz5cclxuPC9MYWJlbD5cclxuICAgICAgICAgICAgPC9TdGFja0xheW91dD5cclxuICAgICAgICA8L1RhYkNvbnRlbnRJdGVtPlxyXG5cclxuICAgICAgICA8VGFiQ29udGVudEl0ZW0+XHJcbiAgICAgICAgICAgIDxTdGFja0xheW91dD5cclxuICAgICAgICAgICAgICAgIDxMYWJlbCB0ZXh0PVwiQm90dG9tIE5hdiBDb250ZW50IDRcIiBjbGFzcz1cImgxIHRleHQtY2VudGVyIHAtdC0yMFwiPjwvTGFiZWw+XHJcbiAgICAgICAgICAgIDwvU3RhY2tMYXlvdXQ+XHJcbiAgICAgICAgPC9UYWJDb250ZW50SXRlbT5cclxuXHJcbiAgICAgICAgPFRhYkNvbnRlbnRJdGVtPlxyXG4gICAgICAgICAgICA8U3RhY2tMYXlvdXQ+XHJcbiAgICAgICAgICAgICAgICA8TGFiZWwgdGV4dD1cIkJvdHRvbSBOYXYgQ29udGVudCA1XCIgY2xhc3M9XCJoMSB0ZXh0LWNlbnRlciBwLXQtMjBcIj48L0xhYmVsPlxyXG4gICAgICAgICAgICA8L1N0YWNrTGF5b3V0PlxyXG4gICAgICAgIDwvVGFiQ29udGVudEl0ZW0+XHJcbiAgICA8L0JvdHRvbU5hdmlnYXRpb24+XHJcblxyXG5cclxuICAgIDwvUGFnZT5cclxuPC90ZW1wbGF0ZT5cclxuXHJcbjxzY3JpcHQ+XHJcbiAgICBpbXBvcnQgTG9naW4gZnJvbSBcIi4vTG9naW5cIjtcclxuICAgIGltcG9ydCB7IG1hcFN0YXRlIH0gZnJvbSAndnVleCc7XHJcbiAgICBpbXBvcnQgSXRlbSBmcm9tIFwiLi9jdXN0b20vaXRlbVwiO1xyXG4gICAgaW1wb3J0IENhdGVnb3J5IGZyb20gXCIuL2N1c3RvbS9jYXRlZ29yeVwiO1xyXG4gICAgaW1wb3J0IFdlYXRoZXIgZnJvbSBcIi4vV2VhdGhlclwiO1xyXG4gICAgZXhwb3J0IGRlZmF1bHQge1xyXG4gICAgICAgIGNvbXBvbmVudHM6IHtcclxuXHRcdEl0ZW0sXHJcblx0XHRDYXRlZ29yeVxyXG5cdCAgICB9LFxyXG4gICAgICAgIGRhdGEoKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAvL21lc3NhZ2U6IFwiV2VsY29tZS4uXCIsXHJcbiAgICAgICAgICAgICAgICBzYWxkbzowLFxyXG4gICAgICAgICAgICAgICAgdXNlckRhdGE6dGhpcy4kc3RvcmUuc3RhdGUudXNlcixcclxuICAgICAgICAgICAgICAgIHNlbGVjdGVkVGFiOiAwLFxyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRUYWJ2aWV3OiAwLFxyXG4gICAgICAgICAgICAgICAgaXRlbXM6IFt7XHJcblx0XHRcdFx0bmFtZTogXCJNYW5pbGEgVWx0aW1hdGUgVG9tYnN0b25lIEJ1cmdlclwiLFxyXG5cdFx0XHRcdGNvdmVyOiBcIn4vYXNzZXRzL2ltYWdlcy9mb29kL2J1cmdlcjY0MC5qcGdcIixcclxuXHRcdFx0XHRpbWFnZXM6IFtcclxuXHRcdFx0XHRcdFx0e3NyYzogXCJ+L2Fzc2V0cy9pbWFnZXMvZm9vZC9idXJnZXIvYnVyZ2VyMS5qcGdcIn0sXHJcblx0XHRcdFx0XHRcdHtzcmM6IFwifi9hc3NldHMvaW1hZ2VzL2Zvb2QvYnVyZ2VyL2J1cmdlcjIuanBnXCJ9LFxyXG5cdFx0XHRcdFx0XHR7c3JjOiBcIn4vYXNzZXRzL2ltYWdlcy9mb29kL2J1cmdlci9idXJnZXIzLmpwZ1wifSxcclxuXHRcdFx0XHRcdFx0e3NyYzogXCJ+L2Fzc2V0cy9pbWFnZXMvZm9vZC9idXJnZXIvYnVyZ2VyNC5qcGdcIn0sXHJcblx0XHRcdFx0XHRcdHtzcmM6IFwifi9hc3NldHMvaW1hZ2VzL2Zvb2QvYnVyZ2VyL2J1cmdlcjUuanBnXCJ9LFxyXG5cdFx0XHRcdFx0XHR7c3JjOiBcIn4vYXNzZXRzL2ltYWdlcy9mb29kL2J1cmdlci9idXJnZXI2LmpwZ1wifVxyXG5cdFx0XHRcdFx0XSxcclxuXHRcdFx0XHRjYXRlZ29yeTogXCJCdXJnZXJcIixcclxuXHRcdFx0XHRjYXRlZ29yeVRhZzogXCIjMkQ5Q0RCXCIsXHJcblx0XHRcdFx0cHJpY2U6IFwiMzAwLjAwXCIsXHJcblx0XHRcdFx0bGlrZXM6IDk4NyxcclxuXHRcdFx0XHRpc0xpa2U6IGZhbHNlLFxyXG5cdFx0XHRcdGlzRmF2b3JpdGU6IHRydWUsXHJcblx0XHRcdFx0Y29tbWVudHM6IDEzLFxyXG5cdFx0XHRcdHJhdGluZzogXCI0LjVcIixcclxuICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcImFcIixcclxuICAgICAgICAgICAgICAgIGp1ZHVsOlwiSG9tZVwiXHJcblx0XHRcdH0sXHJcblx0XHRcdHtcclxuXHRcdFx0XHRuYW1lOiBcIlF1ZXpvbiBDaG9jb2xhdGUgTWFyYmxlIFBhbmNha2VcIixcclxuXHRcdFx0XHRjb3ZlcjogXCJ+L2Fzc2V0cy9pbWFnZXMvZm9vZC9wYW5jYWtlNjQwLmpwZ1wiLFxyXG5cdFx0XHRcdGltYWdlczogW1xyXG5cdFx0XHRcdFx0e3NyYzogXCJ+L2Fzc2V0cy9pbWFnZXMvZm9vZC9wYW5jYWtlL3BhbmNha2UxLmpwZ1wifSxcclxuXHRcdFx0XHRcdHtzcmM6IFwifi9hc3NldHMvaW1hZ2VzL2Zvb2QvcGFuY2FrZS9wYW5jYWtlMi5qcGdcIn0sXHJcblx0XHRcdFx0XHR7c3JjOiBcIn4vYXNzZXRzL2ltYWdlcy9mb29kL3BhbmNha2UvcGFuY2FrZTMuanBnXCJ9LFxyXG5cdFx0XHRcdFx0e3NyYzogXCJ+L2Fzc2V0cy9pbWFnZXMvZm9vZC9wYW5jYWtlL3BhbmNha2U0LmpwZ1wifSxcclxuXHRcdFx0XHRcdHtzcmM6IFwifi9hc3NldHMvaW1hZ2VzL2Zvb2QvcGFuY2FrZS9wYW5jYWtlNS5qcGdcIn0sXHJcblx0XHRcdFx0XHR7c3JjOiBcIn4vYXNzZXRzL2ltYWdlcy9mb29kL3BhbmNha2UvcGFuY2FrZTYuanBnXCJ9XHJcblx0XHRcdFx0XSxcclxuXHRcdFx0XHRjYXRlZ29yeTogXCJQYW5jYWtlXCIsXHJcblx0XHRcdFx0Y2F0ZWdvcnlUYWc6IFwiI2U0Y2UwZFwiLFxyXG5cdFx0XHRcdHByaWNlOiBcIjIzMC4wMFwiLFxyXG5cdFx0XHRcdGxpa2VzOiA4OTEsXHJcblx0XHRcdFx0aXNMaWtlOiB0cnVlLFxyXG5cdFx0XHRcdGlzRmF2b3JpdGU6IHRydWUsXHJcblx0XHRcdFx0Y29tbWVudHM6IDcsXHJcblx0XHRcdFx0cmF0aW5nOiBcIjQuMFwiLFxyXG5cdFx0XHRcdGRlc2NyaXB0aW9uOiBcImFcIlxyXG5cdFx0XHR9LFxyXG5cdFx0XHR7XHJcblx0XHRcdFx0bmFtZTogXCJCaW5vbmRvIEJsYWNrIEZvcmVzdCBDYWtlXCIsXHJcblx0XHRcdFx0Y292ZXI6IFwifi9hc3NldHMvaW1hZ2VzL2Zvb2QvY2FrZTY0MC5qcGdcIixcclxuXHRcdFx0XHRpbWFnZXM6IFtcclxuXHRcdFx0XHRcdHtzcmM6IFwifi9hc3NldHMvaW1hZ2VzL2Zvb2QvY2FrZS9jYWtlMS5qcGdcIn0sXHJcblx0XHRcdFx0XHR7c3JjOiBcIn4vYXNzZXRzL2ltYWdlcy9mb29kL2Nha2UvY2FrZTIuanBnXCJ9LFxyXG5cdFx0XHRcdFx0e3NyYzogXCJ+L2Fzc2V0cy9pbWFnZXMvZm9vZC9jYWtlL2Nha2UzLmpwZ1wifSxcclxuXHRcdFx0XHRcdHtzcmM6IFwifi9hc3NldHMvaW1hZ2VzL2Zvb2QvY2FrZS9jYWtlNC5qcGdcIn1cclxuXHRcdFx0XHRdLFxyXG5cdFx0XHRcdGNhdGVnb3J5OiBcIkNha2VcIixcclxuXHRcdFx0XHRjYXRlZ29yeVRhZzogXCIjMjdBRTYwXCIsXHJcblx0XHRcdFx0cHJpY2U6IFwiMzAwLjAwXCIsXHJcblx0XHRcdFx0bGlrZXM6IDczMCxcclxuXHRcdFx0XHRpc0xpa2U6IHRydWUsXHJcblx0XHRcdFx0aXNGYXZvcml0ZTogdHJ1ZSxcclxuXHRcdFx0XHRjb21tZW50czogMTEsXHJcblx0XHRcdFx0cmF0aW5nOiBcIjQuMFwiLFxyXG5cdFx0XHRcdGRlc2NyaXB0aW9uOiBcImFcIlxyXG5cdFx0XHR9LFxyXG5cdFx0XHRdLFxyXG5cdFx0XHRjYXRlZ29yeTogW1xyXG5cdFx0XHR7XHJcblx0XHRcdFx0Y292ZXI6IFwifi9hc3NldHMvaW1hZ2VzL2Zvb2QvYnVyZ2VyNjQwLmpwZ1wiLFxyXG5cdFx0XHRcdGNhdGVnb3J5OiBcIkJVUkdFUlwiLFxyXG5cdFx0XHRcdGNvdW50OiBcIjEzXCIsXHJcblx0XHRcdH0sXHJcblx0XHRcdHtcclxuXHRcdFx0XHRjb3ZlcjogXCJ+L2Fzc2V0cy9pbWFnZXMvZm9vZC9wYW5jYWtlNjQwLmpwZ1wiLFxyXG5cdFx0XHRcdGNhdGVnb3J5OiBcIlBBTkNBS0VcIixcclxuXHRcdFx0XHRjb3VudDogXCI1XCIsXHJcblx0XHRcdH0sXHJcblx0XHRcdHtcclxuXHRcdFx0XHRjb3ZlcjogXCJ+L2Fzc2V0cy9pbWFnZXMvZm9vZC9jYWtlNjQwLmpwZ1wiLFxyXG5cdFx0XHRcdGNhdGVnb3J5OiBcIkNBS0VcIixcclxuXHRcdFx0XHRjb3VudDogXCI5XCIsXHJcblx0XHRcdH0sXHJcblx0XHRcdHtcclxuXHRcdFx0XHRjb3ZlcjogXCJ+L2Fzc2V0cy9pbWFnZXMvZm9vZC9iZWVyNjQwLmpwZ1wiLFxyXG5cdFx0XHRcdGNhdGVnb3J5OiBcIkJFRVJcIixcclxuXHRcdFx0XHRjb3VudDogXCI3XCIsXHJcblx0XHRcdH0sXHJcblx0XHRcclxuXHRcdFx0XVxyXG5cdFx0XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfSxcclxuICAgICAgICBjb21wdXRlZDp7XHJcblxyXG4gICAgICAgICAgICBpdGVtc0NhdGVnb3J5KCl7XHJcblx0XHRcdHJldHVybiB0aGlzLmNhdGVnb3J5LnNsaWNlKCkucmV2ZXJzZSgpO1xyXG5cdFx0ICAgIH0sXHJcbiAgICAgICAgICAgIGdldFNhbGRvKCl7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5zYWxkb1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB3ZWxjb21lKCl7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gXCJObyBIUCBhbmRhIFwiICsgdGhpcy51c2VyRGF0YS5ub19ocFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAuLi5tYXBTdGF0ZShbJ3VzZXInLCdtZXNzYWdlJ10pXHJcbiAgICAgICAgfSxcclxuICAgICAgICBtZXRob2RzOiB7XHJcbiAgICAgICAgbG9nb3V0KCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy4kc3RvcmVcclxuICAgICAgICAgICAgICAgICAgICAuZGlzcGF0Y2goJ2xvZ291dCcpXHJcbiAgICAgICAgICAgICAgICAgICAgLnRoZW4oKCkgPT4geyAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL3RoaXMuYWxlcnQoXCJTYW1wYWkganVtcGEgbGFnaS4uLlwiKTsgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRuYXZpZ2F0ZVRvKExvZ2luLCB7IGNsZWFySGlzdG9yeTogdHJ1ZSB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgaG9tZSgpIHtcclxuICAgICAgICAgICAgdGhpcy5zZWxlY3RlZFRhYiA9IDA7XHJcbiAgICAgICAgICAgIHRoaXMuanVkdWwgPSdIb21lJztcclxuXHRcdH0sXHJcblx0XHRvcmRlcigpIHtcclxuICAgICAgICAgICAgdGhpcy5zZWxlY3RlZFRhYiA9IDE7XHJcbiAgICAgICAgICAgIHRoaXMuanVkdWwgPSAnT3JkZXInO1xyXG5cdFx0fSxcclxuXHRcdGNoYXQoKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2VsZWN0ZWRUYWIgPSAyO1xyXG4gICAgICAgICAgICB0aGlzLmp1ZHVsID0gJ0NoYXQnO1xyXG5cdFx0fSxcclxuXHRcdGJlbGFuamFhbigpIHtcclxuICAgICAgICAgICAgdGhpcy5zZWxlY3RlZFRhYiA9IDQ7XHJcbiAgICAgICAgICAgIHRoaXMuanVkdWwgPSAnQmVsYW5qYWFuJztcclxuICAgICAgICB9LFxyXG4gICAgICAgIHBlbmdhdHVyYW4oKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2VsZWN0ZWRUYWIgPSA1O1xyXG4gICAgICAgICAgICB0aGlzLmp1ZHVsID0gJ1BlbmdhdHVyYW4nXHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIH1cclxuICAgIH07XHJcbjwvc2NyaXB0PlxyXG5cclxuPHN0eWxlPlxyXG4gICAgLm5hdkJvdHRvbSB7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmMzMwMDtcclxuICAgICAgICBib3JkZXItY29sb3I6ICNmZjMzMDA7XHJcbiAgICAgICAgY29sb3I6I2ZmZmZmZjtcclxuICAgIH1cclxuXHJcbkFjdGlvbkJhciB7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgICB9XHJcblxyXG4gICAgLmFsYnVtLWltYWdlIHtcclxuICAgICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbiAgICAgICAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xyXG4gICAgfVxyXG5cclxuICAgIC5ob21lLXBhbmVsIHtcclxuICAgICAgICB2ZXJ0aWNhbC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjA7XHJcbiAgICAgICAgbWFyZ2luOiAxNTtcclxuICAgIH1cclxuXHJcbiAgICAuZGVzY3JpcHRpb24tbGFiZWwge1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDE1O1xyXG4gICAgfVxyXG5cclxuICAgICNzZWFyY2hSb3cge1xyXG4gICAgICAgIG1hcmdpbi10b3A6IDIwO1xyXG4gICAgfVxyXG48L3N0eWxlPlxyXG4iLCJ2YXIgcmVuZGVyID0gZnVuY3Rpb24oKSB7XG4gIHZhciBfdm0gPSB0aGlzXG4gIHZhciBfaCA9IF92bS4kY3JlYXRlRWxlbWVudFxuICB2YXIgX2MgPSBfdm0uX3NlbGYuX2MgfHwgX2hcbiAgcmV0dXJuIF9jKFxuICAgIFwiR3JpZExheW91dFwiLFxuICAgIHsgYXR0cnM6IHsgcm93czogXCIqLGF1dG8sKixhdXRvLCBhdXRvXCIgfSB9LFxuICAgIFtcbiAgICAgIF9jKFwiSW1hZ2VcIiwge1xuICAgICAgICBhdHRyczoge1xuICAgICAgICAgIHNyYzpcbiAgICAgICAgICAgIFwiaHR0cHM6Ly9zN2QyLnNjZW5lNy5jb20vaXMvaW1hZ2UvVFdDTmV3cy8xMDMxX25jX3N1bm55X3dlYXRoZXJfMi0xXCIsXG4gICAgICAgICAgaW9zT3ZlcmZsb3dTYWZlQXJlYTogXCJ0cnVlXCIsXG4gICAgICAgICAgc3RyZXRjaDogXCJhc3BlY3RGaWxsXCIsXG4gICAgICAgICAgcm93U3BhbjogXCI1XCJcbiAgICAgICAgfVxuICAgICAgfSksXG4gICAgICBfYyhcbiAgICAgICAgXCJTdGFja0xheW91dFwiLFxuICAgICAgICB7IHN0YXRpY0NsYXNzOiBcInRleHQtY2VudGVyXCIsIGF0dHJzOiB7IHJvdzogXCIxXCIgfSB9LFxuICAgICAgICBbXG4gICAgICAgICAgX2MoXCJMYWJlbFwiLCB7XG4gICAgICAgICAgICBzdGF0aWNDbGFzczogXCJoMVwiLFxuICAgICAgICAgICAgYXR0cnM6IHsgdGV4dDogXCJKYWthcnRhXCIsIGNvbG9yOiBcIiNmZmZmZmZcIiB9XG4gICAgICAgICAgfSksXG4gICAgICAgICAgX2MoXCJMYWJlbFwiLCB7XG4gICAgICAgICAgICBzdGF0aWNDbGFzczogXCJoMlwiLFxuICAgICAgICAgICAgYXR0cnM6IHsgdGV4dDogXCJDbG91ZHlcIiwgY29sb3I6IFwiI2ZmZmZmZlwiIH1cbiAgICAgICAgICB9KSxcbiAgICAgICAgICBfYyhcIkxhYmVsXCIsIHtcbiAgICAgICAgICAgIHN0YXRpY0NsYXNzOiBcImgxXCIsXG4gICAgICAgICAgICBhdHRyczogeyB0ZXh0OiBcIjMzXCIsIGNvbG9yOiBcIiNmZmZmZmZcIiB9XG4gICAgICAgICAgfSlcbiAgICAgICAgXSxcbiAgICAgICAgMVxuICAgICAgKSxcbiAgICAgIF9jKFxuICAgICAgICBcIlNjcm9sbFZpZXdcIixcbiAgICAgICAgeyBhdHRyczogeyByb3c6IFwiM1wiLCBvcmllbnRhdGlvbjogXCJob3Jpem9udGFsXCIgfSB9LFxuICAgICAgICBbXG4gICAgICAgICAgX2MoXG4gICAgICAgICAgICBcIlN0YWNrTGF5b3V0XCIsXG4gICAgICAgICAgICB7IGF0dHJzOiB7IG9yaWVudGF0aW9uOiBcImhvcml6b250YWxcIiB9IH0sXG4gICAgICAgICAgICBbXG4gICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgIFwiU3RhY2tMYXlvdXRcIixcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICBzdGF0aWNDbGFzczogXCJ0ZXh0LWNlbnRlclwiLFxuICAgICAgICAgICAgICAgICAgc3RhdGljU3R5bGU6IHsgY29sb3I6IFwid2hpdGVcIiwgbWFyZ2luOiBcIjEwXCIsIGZvbnRTaXplOiBcIjEzXCIgfVxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgX2MoXCJMYWJlbFwiLCB7IGF0dHJzOiB7IHRleHQ6IFwiTm93XCIgfSB9KSxcbiAgICAgICAgICAgICAgICAgIF9jKFwiSW1hZ2VcIiwge1xuICAgICAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgICAgIHNyYzpcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiaHR0cHM6Ly9jZG4ucGl4YWJheS5jb20vcGhvdG8vMjAxNS8xMi8wMy8xNS80My9zdW4tMTA3NTE1NF85NjBfNzIwLnBuZ1wiLFxuICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogXCIyMFwiLFxuICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbjogXCI1XCJcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgICBfYyhcIkxhYmVsXCIsIHsgYXR0cnM6IHsgdGV4dDogXCI3OVwiIH0gfSlcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICAgX2MoXG4gICAgICAgICAgICAgICAgXCJTdGFja0xheW91dFwiLFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgIHN0YXRpY0NsYXNzOiBcInRleHQtY2VudGVyXCIsXG4gICAgICAgICAgICAgICAgICBzdGF0aWNTdHlsZTogeyBjb2xvcjogXCJ3aGl0ZVwiLCBtYXJnaW46IFwiMTBcIiwgZm9udFNpemU6IFwiMTNcIiB9XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBbXG4gICAgICAgICAgICAgICAgICBfYyhcIkxhYmVsXCIsIHsgYXR0cnM6IHsgdGV4dDogXCIxMGFtXCIgfSB9KSxcbiAgICAgICAgICAgICAgICAgIF9jKFwiSW1hZ2VcIiwge1xuICAgICAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgICAgIHNyYzpcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiaHR0cHM6Ly9jZG4ucGl4YWJheS5jb20vcGhvdG8vMjAxNS8xMi8wMy8xNS80My9zdW4tMTA3NTE1NF85NjBfNzIwLnBuZ1wiLFxuICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogXCIyMFwiLFxuICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbjogXCI1XCJcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgICBfYyhcIkxhYmVsXCIsIHsgYXR0cnM6IHsgdGV4dDogXCI4MVwiIH0gfSlcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIDFcbiAgICAgICAgICApXG4gICAgICAgIF0sXG4gICAgICAgIDFcbiAgICAgIClcbiAgICBdLFxuICAgIDFcbiAgKVxufVxudmFyIHN0YXRpY1JlbmRlckZucyA9IFtdXG5yZW5kZXIuX3dpdGhTdHJpcHBlZCA9IHRydWVcblxuZXhwb3J0IHsgcmVuZGVyLCBzdGF0aWNSZW5kZXJGbnMgfSIsImltcG9ydCB7IHJlbmRlciwgc3RhdGljUmVuZGVyRm5zIH0gZnJvbSBcIi4vV2VhdGhlci52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9MDcxNjEzMmUmXCJcbnZhciBzY3JpcHQgPSB7fVxuXG5cbi8qIG5vcm1hbGl6ZSBjb21wb25lbnQgKi9cbmltcG9ydCBub3JtYWxpemVyIGZyb20gXCIhLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvbGliL3J1bnRpbWUvY29tcG9uZW50Tm9ybWFsaXplci5qc1wiXG52YXIgY29tcG9uZW50ID0gbm9ybWFsaXplcihcbiAgc2NyaXB0LFxuICByZW5kZXIsXG4gIHN0YXRpY1JlbmRlckZucyxcbiAgZmFsc2UsXG4gIG51bGwsXG4gIG51bGwsXG4gIG51bGxcbiAgXG4pXG5cbi8qIGhvdCByZWxvYWQgKi9cbmlmIChtb2R1bGUuaG90KSB7XG4gIHZhciBhcGkgPSByZXF1aXJlKFwiL1VzZXJzL21hY2Jvb2svSGVsb0FkYURpc2luaS9ub2RlX21vZHVsZXMvdnVlLWhvdC1yZWxvYWQtYXBpL2Rpc3QvaW5kZXguanNcIilcbiAgYXBpLmluc3RhbGwocmVxdWlyZSgndnVlJykpXG4gIGlmIChhcGkuY29tcGF0aWJsZSkge1xuICAgIG1vZHVsZS5ob3QuYWNjZXB0KClcbiAgICBpZiAoIW1vZHVsZS5ob3QuZGF0YSkge1xuICAgICAgYXBpLmNyZWF0ZVJlY29yZCgnMDcxNjEzMmUnLCBjb21wb25lbnQub3B0aW9ucylcbiAgICB9IGVsc2Uge1xuICAgICAgYXBpLnJlbG9hZCgnMDcxNjEzMmUnLCBjb21wb25lbnQub3B0aW9ucylcbiAgICB9XG4gICAgbW9kdWxlLmhvdC5hY2NlcHQoXCIuL1dlYXRoZXIudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTA3MTYxMzJlJlwiLCBmdW5jdGlvbiAoKSB7XG4gICAgICBhcGkucmVyZW5kZXIoJzA3MTYxMzJlJywge1xuICAgICAgICByZW5kZXI6IHJlbmRlcixcbiAgICAgICAgc3RhdGljUmVuZGVyRm5zOiBzdGF0aWNSZW5kZXJGbnNcbiAgICAgIH0pXG4gICAgfSlcbiAgfVxufVxuY29tcG9uZW50Lm9wdGlvbnMuX19maWxlID0gXCJjb21wb25lbnRzL1dlYXRoZXIudnVlXCJcbmV4cG9ydCBkZWZhdWx0IGNvbXBvbmVudC5leHBvcnRzIiwiZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvbGliL2xvYWRlcnMvdGVtcGxhdGVMb2FkZXIuanM/P3Z1ZS1sb2FkZXItb3B0aW9ucyEuLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9saWIvaW5kZXguanM/P3Z1ZS1sb2FkZXItb3B0aW9ucyEuL1dlYXRoZXIudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTA3MTYxMzJlJlwiIl0sInNvdXJjZVJvb3QiOiIifQ==
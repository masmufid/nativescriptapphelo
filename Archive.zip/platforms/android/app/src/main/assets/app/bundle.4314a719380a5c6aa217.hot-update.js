webpackHotUpdate("bundle",{

/***/ "./app.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(global) {/* harmony import */ var nativescript_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("nativescript-vue");
/* harmony import */ var nativescript_vue__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(nativescript_vue__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Welcome__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./components/Welcome.vue");
/* harmony import */ var tns_core_modules_application_settings__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("tns-core-modules/application-settings");
/* harmony import */ var tns_core_modules_application_settings__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(tns_core_modules_application_settings__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("../node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./store.js");
/* harmony import */ var _nativescript_fonticon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./nativescript-fonticon/nativescript-fonticon.js");
/* harmony import */ var _nativescript_fonticon__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_nativescript_fonticon__WEBPACK_IMPORTED_MODULE_5__);

        let applicationCheckPlatform = __webpack_require__("tns-core-modules/application");
        if (applicationCheckPlatform.android && !global["__snapshot"]) {
            __webpack_require__("tns-core-modules/ui/frame");
__webpack_require__("tns-core-modules/ui/frame/activity");
        }

        
            __webpack_require__("../node_modules/nativescript-dev-webpack/load-application-css-regular.js")();
            
            
        if (true) {
            const hmrUpdate = __webpack_require__("../node_modules/nativescript-dev-webpack/hmr/index.js").hmrUpdate;
            global.__coreModulesLiveSync = global.__onLiveSync;

            global.__onLiveSync = function () {
                // handle hot updated on LiveSync
                hmrUpdate();
            };

            global.hmrRefresh = function({ type, path } = {}) {
                // the hot updates are applied, ask the modules to apply the changes
                setTimeout(() => {
                    global.__coreModulesLiveSync({ type, path });
                });
            };

            // handle hot updated on initial app start
            hmrUpdate();
        }
        
            const context = __webpack_require__("./ sync recursive (?<!\\bApp_Resources\\b.*)(?<!\\.\\/\\btests\\b\\/.*?)\\.(xml|css|js|kt|(?<!\\.d\\.)ts|(?<!\\b_[\\w-]*\\.)scss)$");
            global.registerWebpackModules(context);
            if (true) {
                module.hot.accept(context.id, () => { 
                    console.log("HMR: Accept module '" + context.id + "' from '" + module.i + "'"); 
                });
            }
            
        __webpack_require__("tns-core-modules/bundle-entry-points");
        



nativescript_vue__WEBPACK_IMPORTED_MODULE_0___default.a.use(vuex__WEBPACK_IMPORTED_MODULE_3__["default"]);


const appSettings = __webpack_require__("tns-core-modules/application-settings");


_nativescript_fonticon__WEBPACK_IMPORTED_MODULE_5__["TNSFontIcon"].debug = true;
_nativescript_fonticon__WEBPACK_IMPORTED_MODULE_5__["TNSFontIcon"].paths = {
  'fa': './fonts/font-awesome.css',
  'ion': './fonts/ionicons.css'
};
_nativescript_fonticon__WEBPACK_IMPORTED_MODULE_5__["TNSFontIcon"].loadCss();
nativescript_vue__WEBPACK_IMPORTED_MODULE_0___default.a.filter('fonticon', _nativescript_fonticon__WEBPACK_IMPORTED_MODULE_5__["fonticon"]);
nativescript_vue__WEBPACK_IMPORTED_MODULE_0___default.a.registerElement("PreviousNextView", () => __webpack_require__("nativescript-iqkeyboardmanager").PreviousNextView);
new nativescript_vue__WEBPACK_IMPORTED_MODULE_0___default.a({
  store: _store__WEBPACK_IMPORTED_MODULE_4__["default"],

  created() {
    const userString = appSettings.getString('user'); // grab user data from local storage

    if (userString) {
      // check to see if there is indeed a user
      const userData = JSON.parse(userString); // parse user data into JSON

      this.$store.commit('SET_USER_DATA', userData); // restore user data with Vuex
    }
  },

  render: h => h('frame', [h(_components_Welcome__WEBPACK_IMPORTED_MODULE_1__["default"])])
}).$start();
    
        
        
    
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__("../node_modules/webpack/buildin/global.js")))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9hcHAuanMiXSwibmFtZXMiOlsiV2VsY29tZSIsImdldFN0cmluZyIsIlZ1ZXgiLCJWdWUiLCJzdG9yZSIsImFwcFNldHRpbmdzIiwiVE5TRm9udEljb24iLCJwYXRocyIsImxvYWRDc3MiLCJmaWx0ZXIiLCJmb250aWNvbiIsInJlZ2lzdGVyRWxlbWVudCIsImNyZWF0ZWQiLCJ1c2VyU3RyaW5nIiwiJHN0b3JlIiwiY29tbWl0IiwicmVuZGVyIiwiaCIsIiRzdGFydCJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLE9BQU9BLE9BQVAsTUFBb0Isc0NBQXBCO0FBQ0EsU0FBU0MsU0FBVCxRQUEwQix1Q0FBMUI7QUFDQSxPQUFPQyxJQUFQLG9CQUFpQiw0QkFBakI7QUFDQUMsbUJBQUEsQ0FBUUQsb0NBQVI7QUFDQSxPQUFPRSxFQUFQOztBQUNBLE1BQU1DLEVBQU47O0FBQ0EsU0FBU0MsR0FBVDtBQUNBQSxXQUFXLENBQVg7QUFDQUEsV0FBVyxDQUFDQyxJQUFRO0FBQ2hCLFFBQU0seUNBRFU7QUFFaEIsU0FBTztBQUZYO0FBSUFELFdBQVcsQ0FBQ0UsT0FBWjtBQUNBTCxHQUFHLENBQUNNLE1BQUosQ0FBVyxVQUFYLEVBQXVCQyxRQUF2QjtBQUNBUCxHQUFHLENBQUNRLGVBQUosQ0FBb0IsUUFBcEI7QUFDQSxJQUFJUixHQUFKLENBQVE7QUFBQTs7QUFFSlMsU0FBTyxHQUFJO0FBQ1AsVUFBTUMsVUFBVSxHQUFHUixXQUErQjs7QUFDbEQsUUFBSVEsVUFBSixDQUFnQjtBQUFFO0FBQ3dCOztBQUN4QyxXQUFLQyxNQUFMLENBQVlDLE1BQWtDO0FBQy9DO0FBQ0YsR0FSQzs7QUFTSkMsUUFBTSxFQUFFQyxDQUFDLElBQUlBLENBQUMsQ0FBQyxPQUFELEVBQVUsQ0FBQ0EsQ0FBQyxDQUFDakIsT0FBRCxDQUFGLENBQVY7QUFUVixDQUFSLEVBV0drQixNQVhIIiwiZmlsZSI6ImJ1bmRsZS40MzE0YTcxOTM4MGE1YzZhYTIxNy5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFZ1ZSBmcm9tIFwibmF0aXZlc2NyaXB0LXZ1ZVwiO1xuaW1wb3J0IFdlbGNvbWUgZnJvbSBcIi4vY29tcG9uZW50cy9XZWxjb21lXCI7XG5pbXBvcnQgeyBnZXRTdHJpbmcgfSBmcm9tICd0bnMtY29yZS1tb2R1bGVzL2FwcGxpY2F0aW9uLXNldHRpbmdzJztcbmltcG9ydCBWdWV4IGZyb20gJ3Z1ZXgnO1xuVnVlLnVzZShWdWV4KTtcbmltcG9ydCBzdG9yZSBmcm9tICcuL3N0b3JlJztcbmNvbnN0IGFwcFNldHRpbmdzID0gcmVxdWlyZShcInRucy1jb3JlLW1vZHVsZXMvYXBwbGljYXRpb24tc2V0dGluZ3NcIik7XG5pbXBvcnQgeyBUTlNGb250SWNvbiwgZm9udGljb24gfSBmcm9tICcuL25hdGl2ZXNjcmlwdC1mb250aWNvbic7XG5UTlNGb250SWNvbi5kZWJ1ZyA9IHRydWU7XG5UTlNGb250SWNvbi5wYXRocyA9IHtcbiAgICAnZmEnOiAnLi9mb250cy9mb250LWF3ZXNvbWUuY3NzJyxcbiAgICAnaW9uJzogJy4vZm9udHMvaW9uaWNvbnMuY3NzJyxcbn07XG5UTlNGb250SWNvbi5sb2FkQ3NzKCk7XG5WdWUuZmlsdGVyKCdmb250aWNvbicsIGZvbnRpY29uKTtcblZ1ZS5yZWdpc3RlckVsZW1lbnQoXCJQcmV2aW91c05leHRWaWV3XCIsICgpID0+IHJlcXVpcmUoXCJuYXRpdmVzY3JpcHQtaXFrZXlib2FyZG1hbmFnZXJcIikuIFByZXZpb3VzTmV4dFZpZXcpXG5uZXcgVnVlKHtcbiAgICBzdG9yZSxcbiAgICBjcmVhdGVkICgpIHtcbiAgICAgICAgY29uc3QgdXNlclN0cmluZyA9IGFwcFNldHRpbmdzLmdldFN0cmluZygndXNlcicpOyAvLyBncmFiIHVzZXIgZGF0YSBmcm9tIGxvY2FsIHN0b3JhZ2VcbiAgICAgICAgaWYgKHVzZXJTdHJpbmcpIHsgLy8gY2hlY2sgdG8gc2VlIGlmIHRoZXJlIGlzIGluZGVlZCBhIHVzZXJcbiAgICAgICAgICBjb25zdCB1c2VyRGF0YSA9IEpTT04ucGFyc2UodXNlclN0cmluZykgLy8gcGFyc2UgdXNlciBkYXRhIGludG8gSlNPTlxuICAgICAgICAgIHRoaXMuJHN0b3JlLmNvbW1pdCgnU0VUX1VTRVJfREFUQScsIHVzZXJEYXRhKSAvLyByZXN0b3JlIHVzZXIgZGF0YSB3aXRoIFZ1ZXhcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICByZW5kZXI6IGggPT4gaCgnZnJhbWUnLCBbaChXZWxjb21lKV0pXG4gICBcbn0pLiRzdGFydCgpO1xuIl0sInNvdXJjZVJvb3QiOiIifQ==
webpackHotUpdate("bundle",{

/***/ "../node_modules/babel-loader/lib/index.js!../node_modules/vue-loader/lib/index.js?!./components/Home.vue?vue&type=script&lang=js&":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Login__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./components/Login.vue");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("../node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _custom_item__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./components/custom/item.vue");
/* harmony import */ var _custom_category__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./components/custom/category.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    Item: _custom_item__WEBPACK_IMPORTED_MODULE_2__["default"],
    Category: _custom_category__WEBPACK_IMPORTED_MODULE_3__["default"]
  },

  data() {
    return {
      //message: "Welcome..",
      saldo: 0,
      userData: this.$store.state.user,
      selectedTab: 0,
      selectedTabview: 0,
      items: [{
        name: "Manila Ultimate Tombstone Burger",
        cover: "~/assets/images/food/burger640.jpg",
        images: [{
          src: "~/assets/images/food/burger/burger1.jpg"
        }, {
          src: "~/assets/images/food/burger/burger2.jpg"
        }, {
          src: "~/assets/images/food/burger/burger3.jpg"
        }, {
          src: "~/assets/images/food/burger/burger4.jpg"
        }, {
          src: "~/assets/images/food/burger/burger5.jpg"
        }, {
          src: "~/assets/images/food/burger/burger6.jpg"
        }],
        category: "Burger",
        categoryTag: "#2D9CDB",
        price: "300.00",
        likes: 987,
        isLike: false,
        isFavorite: true,
        comments: 13,
        rating: "4.5",
        description: "a",
        judul: "Home"
      }, {
        name: "Quezon Chocolate Marble Pancake",
        cover: "~/assets/images/food/pancake640.jpg",
        images: [{
          src: "~/assets/images/food/pancake/pancake1.jpg"
        }, {
          src: "~/assets/images/food/pancake/pancake2.jpg"
        }, {
          src: "~/assets/images/food/pancake/pancake3.jpg"
        }, {
          src: "~/assets/images/food/pancake/pancake4.jpg"
        }, {
          src: "~/assets/images/food/pancake/pancake5.jpg"
        }, {
          src: "~/assets/images/food/pancake/pancake6.jpg"
        }],
        category: "Pancake",
        categoryTag: "#e4ce0d",
        price: "230.00",
        likes: 891,
        isLike: true,
        isFavorite: true,
        comments: 7,
        rating: "4.0",
        description: "a"
      }, {
        name: "Binondo Black Forest Cake",
        cover: "~/assets/images/food/cake640.jpg",
        images: [{
          src: "~/assets/images/food/cake/cake1.jpg"
        }, {
          src: "~/assets/images/food/cake/cake2.jpg"
        }, {
          src: "~/assets/images/food/cake/cake3.jpg"
        }, {
          src: "~/assets/images/food/cake/cake4.jpg"
        }],
        category: "Cake",
        categoryTag: "#27AE60",
        price: "300.00",
        likes: 730,
        isLike: true,
        isFavorite: true,
        comments: 11,
        rating: "4.0",
        description: "a"
      }],
      category: [{
        cover: "~/assets/images/food/burger640.jpg",
        category: "BURGER",
        count: "13"
      }, {
        cover: "~/assets/images/food/pancake640.jpg",
        category: "PANCAKE",
        count: "5"
      }, {
        cover: "~/assets/images/food/cake640.jpg",
        category: "CAKE",
        count: "9"
      }, {
        cover: "~/assets/images/food/beer640.jpg",
        category: "BEER",
        count: "7"
      }]
    };
  },

  computed: {
    itemsCategory() {
      return this.category.slice().reverse();
    },

    getSaldo() {
      return this.saldo;
    },

    welcome() {
      return "No HP anda " + this.userData.no_hp;
    },

    ...Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapState"])(['user', 'message'])
  },
  methods: {
    logout() {
      this.$store.dispatch('logout').then(() => {
        //this.alert("Sampai jumpa lagi...");  
        this.$navigateTo(_Login__WEBPACK_IMPORTED_MODULE_0__["default"], {
          clearHistory: true
        });
      });
    },

    home() {
      this.selectedTab = 0;
      this.judul = 'Home';
    },

    order() {
      this.selectedTab = 1;
      this.judul = 'Order';
    },

    chat() {
      this.selectedTab = 2;
      this.judul = 'Chat';
    },

    belanjaan() {
      this.selectedTab = 4;
      this.judul = 'Belanjaan';
    },

    pengaturan() {
      this.selectedTab = 5;
      this.judul = 'Pengaturan';
    }

  }
});

/***/ }),

/***/ "../node_modules/vue-loader/lib/loaders/templateLoader.js?!../node_modules/vue-loader/lib/index.js?!./components/Home.vue?vue&type=template&id=67410f3a&":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "Page",
    { staticClass: "page" },
    [
      _c(
        "ActionBar",
        {
          attrs: { backgroundColor: "#ff3300", flat: "true" },
          on: { tap: _vm.logout }
        },
        [
          _c("Label", {
            staticClass: "action-bar-title",
            attrs: { text: _vm.selectedTab == 0 ? "Home" : _vm.judul }
          })
        ],
        1
      ),
      _c(
        "BottomNavigation",
        { attrs: { backgroundColor: "#000000" } },
        [
          _c(
            "TabStrip",
            [
              _c(
                "TabStripItem",
                {
                  class: _vm.selectedTab == 0 ? "active" : "",
                  on: { tap: _vm.home }
                },
                [
                  _c("Image", { attrs: { src: "~/images/navhome.png" } }),
                  _c("Label", { attrs: { text: "Homy" } })
                ],
                1
              ),
              _c(
                "TabStripItem",
                {
                  class: _vm.selectedTab == 1 ? "active" : "",
                  on: { tap: _vm.order }
                },
                [
                  _c("Image", { attrs: { src: "~/images/navorders.png" } }),
                  _c("Label", { attrs: { text: "Order" } })
                ],
                1
              ),
              _c(
                "TabStripItem",
                {
                  class: _vm.selectedTab == 2 ? "active" : "",
                  on: { tap: _vm.chat }
                },
                [
                  _c("Image", { attrs: { src: "~/images/navus.png" } }),
                  _c("Label", { attrs: { text: "Chat" } })
                ],
                1
              ),
              _c(
                "TabStripItem",
                {
                  class: _vm.selectedTab == 3 ? "active" : "",
                  on: { tap: _vm.belanjaan }
                },
                [
                  _c("Image", { attrs: { src: "~/images/navcart.png" } }),
                  _c("Label", { attrs: { text: "Belanjaan" } })
                ],
                1
              ),
              _c(
                "TabStripItem",
                {
                  class: _vm.selectedTab == 4 ? "active" : "",
                  on: { tap: _vm.pengaturan }
                },
                [
                  _c("Image", { attrs: { src: "~/images/navset.png" } }),
                  _c("Label", { attrs: { text: "Pengaturan" } })
                ],
                1
              )
            ],
            1
          ),
          _c(
            "TabContentItem",
            [
              _c(
                "ScrollView",
                { attrs: { orientation: "vertical" } },
                [
                  _c(
                    "GridLayout",
                    { attrs: { rows: "*,*,*,auto,auto,auto" } },
                    [
                      _c("StackLayout", {
                        staticClass: "album-image",
                        attrs: {
                          row: "0",
                          paddingLeft: "10",
                          paddingRight: "10",
                          paddingBottom: "25",
                          marginTop: "0",
                          backgroundColor: "#ff3300",
                          height: "10%",
                          width: "100%",
                          stretch: "aspectFit"
                        }
                      }),
                      _c(
                        "StackLayout",
                        {
                          staticClass: "album-image",
                          attrs: {
                            row: "1",
                            paddingLeft: "25",
                            paddingRight: "25",
                            paddingTop: "5",
                            paddingBottom: "25",
                            marginTop: "-20",
                            backgroundColor: "#ffffff",
                            borderRadius: "15",
                            height: "10%",
                            width: "90%",
                            stretch: "aspectFit"
                          }
                        },
                        [
                          _c(
                            "GridLayout",
                            { attrs: { columns: "*,*,*", rows: "*,*,*" } },
                            [
                              _c("Image", {
                                attrs: {
                                  col: "0",
                                  row: "0",
                                  src: "~/images/location.png",
                                  stretch: "aspectFit",
                                  horizontalAlignment: "center",
                                  width: "100px"
                                }
                              }),
                              _c("Label", {
                                staticClass: "font-weight-bold",
                                attrs: {
                                  col: "1",
                                  row: "0",
                                  fontSize: "16",
                                  color: "#525151",
                                  text: "Majalaya",
                                  horizontalAlignment: "left",
                                  verticalAlignment: "center"
                                }
                              }),
                              _c("Image", {
                                attrs: {
                                  col: "2",
                                  row: "0",
                                  src: "~/images/logo.png",
                                  stretch: "aspectFit",
                                  horizontalAlignment: "center"
                                }
                              }),
                              _c("Image", {
                                attrs: {
                                  src: "~/images/deposit.png",
                                  row: "1",
                                  col: "0",
                                  stretch: "aspectFit"
                                }
                              }),
                              _c("Image", {
                                attrs: {
                                  src: "~/images/postpaid.png",
                                  row: "1",
                                  col: "1",
                                  stretch: "aspectFit"
                                }
                              }),
                              _c("Image", {
                                attrs: {
                                  src: "~/images/tariktunai.png",
                                  row: "1",
                                  col: "2",
                                  stretch: "aspectFit"
                                }
                              }),
                              _c("Label", {
                                attrs: {
                                  col: "0",
                                  row: "2",
                                  fontSize: "12",
                                  color: "#525151",
                                  text: "Tabungan Sampah",
                                  textAlignment: "center"
                                }
                              }),
                              _c("Label", {
                                attrs: {
                                  col: "1",
                                  row: "2",
                                  fontSize: "12",
                                  color: "#525151",
                                  text: "Top Up/Setor",
                                  textAlignment: "center"
                                }
                              }),
                              _c("Label", {
                                attrs: {
                                  col: "2",
                                  row: "2",
                                  fontSize: "12",
                                  color: "#525151",
                                  text: "Tarik Tunai",
                                  textAlignment: "center"
                                }
                              })
                            ],
                            1
                          )
                        ],
                        1
                      ),
                      _c(
                        "StackLayout",
                        {
                          attrs: {
                            row: "2",
                            paddingLeft: "10",
                            paddingRight: "10",
                            paddingTop: "5",
                            paddingBottom: "5",
                            marginTop: "10",
                            backgroundColor: "#f8f8f8",
                            borderRadius: "15",
                            height: "35%",
                            width: "90%"
                          }
                        },
                        [
                          _c(
                            "GridLayout",
                            { attrs: { columns: "*,*,*,*", rows: "*,*,*,*" } },
                            [
                              _c("Image", {
                                attrs: {
                                  src: "~/images/pulsa.png",
                                  row: "0",
                                  col: "0",
                                  stretch: "aspectFit"
                                }
                              }),
                              _c("Image", {
                                attrs: {
                                  src: "~/images/paketdata.png",
                                  row: "0",
                                  col: "1",
                                  stretch: "aspectFit"
                                }
                              }),
                              _c("Image", {
                                attrs: {
                                  src: "~/images/plnpasca.png",
                                  row: "0",
                                  col: "2",
                                  stretch: "aspectFit"
                                }
                              }),
                              _c("Image", {
                                attrs: {
                                  src: "~/images/postpaid.png",
                                  row: "0",
                                  col: "3",
                                  stretch: "aspectFit"
                                }
                              }),
                              _c("Label", {
                                attrs: {
                                  col: "0",
                                  row: "1",
                                  fontSize: "12",
                                  color: "#525151",
                                  text: "Pulsa/Voucher",
                                  textAlignment: "center"
                                }
                              }),
                              _c("Label", {
                                attrs: {
                                  col: "1",
                                  row: "1",
                                  fontSize: "12",
                                  color: "#525151",
                                  text: "Paket Data",
                                  textAlignment: "center"
                                }
                              }),
                              _c("Label", {
                                attrs: {
                                  col: "2",
                                  row: "1",
                                  fontSize: "12",
                                  color: "#525151",
                                  text: "PLN/Token",
                                  textAlignment: "center"
                                }
                              }),
                              _c("Label", {
                                attrs: {
                                  col: "3",
                                  row: "1",
                                  fontSize: "12",
                                  color: "#525151",
                                  text: "Pasca Bayar",
                                  textAlignment: "center"
                                }
                              }),
                              _c("Image", {
                                attrs: {
                                  src: "~/images/food.png",
                                  row: "2",
                                  col: "0",
                                  stretch: "aspectFit"
                                }
                              }),
                              _c("Image", {
                                attrs: {
                                  src: "~/images/driver.png",
                                  row: "2",
                                  col: "1",
                                  stretch: "aspectFit"
                                }
                              }),
                              _c("Image", {
                                attrs: {
                                  src: "~/images/grosir.png",
                                  row: "2",
                                  col: "2",
                                  stretch: "aspectFit"
                                }
                              }),
                              _c("Image", {
                                attrs: {
                                  src: "~/images/cargo.png",
                                  row: "2",
                                  col: "3",
                                  stretch: "aspectFit"
                                }
                              }),
                              _c("Label", {
                                attrs: {
                                  col: "0",
                                  row: "3",
                                  fontSize: "12",
                                  color: "#525151",
                                  text: "Food",
                                  textAlignment: "center"
                                }
                              }),
                              _c("Label", {
                                attrs: {
                                  col: "1",
                                  row: "3",
                                  fontSize: "12",
                                  color: "#525151",
                                  text: "Driver/Kurir",
                                  textAlignment: "center"
                                }
                              }),
                              _c("Label", {
                                attrs: {
                                  col: "2",
                                  row: "3",
                                  fontSize: "12",
                                  color: "#525151",
                                  text: "Grosir",
                                  textAlignment: "center"
                                }
                              }),
                              _c("Label", {
                                attrs: {
                                  col: "3",
                                  row: "3",
                                  fontSize: "12",
                                  color: "#525151",
                                  text: "Cargo",
                                  textAlignment: "center"
                                }
                              })
                            ],
                            1
                          )
                        ],
                        1
                      ),
                      _c(
                        "StackLayout",
                        {
                          attrs: {
                            row: "3",
                            height: "35%",
                            paddingLeft: "15",
                            paddingRight: "15",
                            marginTop: "10"
                          }
                        },
                        [
                          _c(
                            "ScrollView",
                            { attrs: { orientation: "horizontal" } },
                            [
                              _c(
                                "StackLayout",
                                { attrs: { orientation: "horizontal" } },
                                [
                                  _c(
                                    "StackLayout",
                                    [
                                      _c("Image", {
                                        attrs: {
                                          src: "~/images/bikeday.png",
                                          borderRadius: "15",
                                          height: "25%",
                                          margin: "10",
                                          stretch: "aspectFit"
                                        }
                                      })
                                    ],
                                    1
                                  ),
                                  _c(
                                    "StackLayout",
                                    [
                                      _c("Image", {
                                        attrs: {
                                          src: "~/images/sampah.jpg",
                                          borderRadius: "15",
                                          height: "25%",
                                          margin: "10",
                                          stretch: "aspectFit"
                                        }
                                      })
                                    ],
                                    1
                                  ),
                                  _c(
                                    "StackLayout",
                                    [
                                      _c("Image", {
                                        attrs: {
                                          src: "~/images/agenpulsa.jpg",
                                          borderRadius: "15",
                                          height: "25%",
                                          margin: "10",
                                          stretch: "aspectFit"
                                        }
                                      })
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ],
                            1
                          )
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          ),
          _c(
            "TabContentItem",
            [
              _c(
                "StackLayout",
                [
                  _c(
                    "GridLayout",
                    { attrs: { rows: "*,auto,*,auto, auto" } },
                    [
                      _c("Image", {
                        attrs: {
                          src:
                            "https://s7d2.scene7.com/is/image/TWCNews/1031_nc_sunny_weather_2-1",
                          iosOverflowSafeArea: "true",
                          stretch: "aspectFill",
                          rowSpan: "5"
                        }
                      }),
                      _c(
                        "StackLayout",
                        { staticClass: "text-center", attrs: { row: "1" } },
                        [
                          _c("Label", {
                            staticClass: "h1",
                            attrs: { text: "Jakarta", color: "#ffffff" }
                          }),
                          _c("Label", {
                            staticClass: "h2",
                            attrs: { text: "Cloudy", color: "#ffffff" }
                          }),
                          _c("Label", {
                            staticClass: "h1",
                            attrs: { text: "33", color: "#ffffff" }
                          })
                        ],
                        1
                      ),
                      _c(
                        "ScrollView",
                        { attrs: { row: "3", orientation: "horizontal" } },
                        [
                          _c(
                            "StackLayout",
                            { attrs: { orientation: "horizontal" } },
                            [
                              _c(
                                "StackLayout",
                                {
                                  staticClass: "text-center",
                                  staticStyle: {
                                    color: "white",
                                    margin: "10",
                                    fontSize: "13"
                                  }
                                },
                                [
                                  _c("Label", { attrs: { text: "Now" } }),
                                  _c("Image", {
                                    attrs: {
                                      src:
                                        "https://cdn.pixabay.com/photo/2015/12/03/15/43/sun-1075154_960_720.png",
                                      height: "20",
                                      margin: "5"
                                    }
                                  }),
                                  _c("Label", { attrs: { text: "79" } })
                                ],
                                1
                              ),
                              _c(
                                "StackLayout",
                                {
                                  staticClass: "text-center",
                                  staticStyle: {
                                    color: "white",
                                    margin: "10",
                                    fontSize: "13"
                                  }
                                },
                                [
                                  _c("Label", { attrs: { text: "10am" } }),
                                  _c("Image", {
                                    attrs: {
                                      src:
                                        "https://cdn.pixabay.com/photo/2015/12/03/15/43/sun-1075154_960_720.png",
                                      height: "20",
                                      margin: "5"
                                    }
                                  }),
                                  _c("Label", { attrs: { text: "81" } })
                                ],
                                1
                              )
                            ],
                            1
                          )
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          ),
          _c(
            "TabContentItem",
            [
              _c(
                "StackLayout",
                [
                  _c("Label", {
                    staticClass: "h1 text-center p-t-20",
                    attrs: { text: "Bottom Nav Content 3" }
                  }),
                  _c(
                    "Label",
                    { staticClass: "fas", attrs: { textWrap: "true" } },
                    [
                      _c(
                        "FormattedString",
                        [
                          _c("Span", {
                            attrs: { text: "&#xf053;", fontAttributes: "Bold" }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          ),
          _c(
            "TabContentItem",
            [
              _c(
                "StackLayout",
                [
                  _c("Label", {
                    staticClass: "h1 text-center p-t-20",
                    attrs: { text: "Bottom Nav Content 4" }
                  })
                ],
                1
              )
            ],
            1
          ),
          _c(
            "TabContentItem",
            [
              _c(
                "StackLayout",
                [
                  _c("Label", {
                    staticClass: "h1 text-center p-t-20",
                    attrs: { text: "Bottom Nav Content 5" }
                  })
                ],
                1
              )
            ],
            1
          )
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vY29tcG9uZW50cy9Ib21lLnZ1ZSIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL0hvbWUudnVlP2I2NmIiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXdLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4REFEQTtBQUVBO0FBRkEsR0FEQTs7QUFLQTtBQUNBO0FBQ0E7QUFDQSxjQUZBO0FBR0Esc0NBSEE7QUFJQSxvQkFKQTtBQUtBLHdCQUxBO0FBTUE7QUFDQSxnREFEQTtBQUVBLG1EQUZBO0FBR0EsaUJBQ0E7QUFBQTtBQUFBLFNBREEsRUFFQTtBQUFBO0FBQUEsU0FGQSxFQUdBO0FBQUE7QUFBQSxTQUhBLEVBSUE7QUFBQTtBQUFBLFNBSkEsRUFLQTtBQUFBO0FBQUEsU0FMQSxFQU1BO0FBQUE7QUFBQSxTQU5BLENBSEE7QUFXQSwwQkFYQTtBQVlBLDhCQVpBO0FBYUEsdUJBYkE7QUFjQSxrQkFkQTtBQWVBLHFCQWZBO0FBZ0JBLHdCQWhCQTtBQWlCQSxvQkFqQkE7QUFrQkEscUJBbEJBO0FBbUJBLHdCQW5CQTtBQW9CQTtBQXBCQSxTQXNCQTtBQUNBLCtDQURBO0FBRUEsb0RBRkE7QUFHQSxpQkFDQTtBQUFBO0FBQUEsU0FEQSxFQUVBO0FBQUE7QUFBQSxTQUZBLEVBR0E7QUFBQTtBQUFBLFNBSEEsRUFJQTtBQUFBO0FBQUEsU0FKQSxFQUtBO0FBQUE7QUFBQSxTQUxBLEVBTUE7QUFBQTtBQUFBLFNBTkEsQ0FIQTtBQVdBLDJCQVhBO0FBWUEsOEJBWkE7QUFhQSx1QkFiQTtBQWNBLGtCQWRBO0FBZUEsb0JBZkE7QUFnQkEsd0JBaEJBO0FBaUJBLG1CQWpCQTtBQWtCQSxxQkFsQkE7QUFtQkE7QUFuQkEsT0F0QkEsRUEyQ0E7QUFDQSx5Q0FEQTtBQUVBLGlEQUZBO0FBR0EsaUJBQ0E7QUFBQTtBQUFBLFNBREEsRUFFQTtBQUFBO0FBQUEsU0FGQSxFQUdBO0FBQUE7QUFBQSxTQUhBLEVBSUE7QUFBQTtBQUFBLFNBSkEsQ0FIQTtBQVNBLHdCQVRBO0FBVUEsOEJBVkE7QUFXQSx1QkFYQTtBQVlBLGtCQVpBO0FBYUEsb0JBYkE7QUFjQSx3QkFkQTtBQWVBLG9CQWZBO0FBZ0JBLHFCQWhCQTtBQWlCQTtBQWpCQSxPQTNDQSxDQU5BO0FBcUVBLGlCQUNBO0FBQ0EsbURBREE7QUFFQSwwQkFGQTtBQUdBO0FBSEEsT0FEQSxFQU1BO0FBQ0Esb0RBREE7QUFFQSwyQkFGQTtBQUdBO0FBSEEsT0FOQSxFQVdBO0FBQ0EsaURBREE7QUFFQSx3QkFGQTtBQUdBO0FBSEEsT0FYQSxFQWdCQTtBQUNBLGlEQURBO0FBRUEsd0JBRkE7QUFHQTtBQUhBLE9BaEJBO0FBckVBO0FBOEZBLEdBcEdBOztBQXFHQTtBQUVBO0FBQ0E7QUFDQSxLQUpBOztBQUtBO0FBQ0E7QUFDQSxLQVBBOztBQVFBO0FBQ0E7QUFDQSxLQVZBOztBQVdBO0FBWEEsR0FyR0E7QUFrSEE7QUFDQTtBQUNBLGtCQUNBLFFBREEsQ0FDQSxRQURBLEVBRUEsSUFGQSxDQUVBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFDQSxPQUxBO0FBTUEsS0FSQTs7QUFTQTtBQUNBO0FBQ0E7QUFDQSxLQVpBOztBQWFBO0FBQ0E7QUFDQTtBQUNBLEtBaEJBOztBQWlCQTtBQUNBO0FBQ0E7QUFDQSxLQXBCQTs7QUFxQkE7QUFDQTtBQUNBO0FBQ0EsS0F4QkE7O0FBeUJBO0FBQ0E7QUFDQTtBQUNBOztBQTVCQTtBQWxIQSxHOzs7Ozs7OztBQzVLQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLLHNCQUFzQjtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQiwyQ0FBMkM7QUFDN0QsZUFBZTtBQUNmLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSxvQkFBb0I7QUFDcEIsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTLFNBQVMsNkJBQTZCLEVBQUU7QUFDakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QjtBQUN2QixpQkFBaUI7QUFDakI7QUFDQSwrQkFBK0IsU0FBUyw4QkFBOEIsRUFBRTtBQUN4RSwrQkFBK0IsU0FBUyxlQUFlLEVBQUU7QUFDekQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUI7QUFDdkIsaUJBQWlCO0FBQ2pCO0FBQ0EsK0JBQStCLFNBQVMsZ0NBQWdDLEVBQUU7QUFDMUUsK0JBQStCLFNBQVMsZ0JBQWdCLEVBQUU7QUFDMUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUI7QUFDdkIsaUJBQWlCO0FBQ2pCO0FBQ0EsK0JBQStCLFNBQVMsNEJBQTRCLEVBQUU7QUFDdEUsK0JBQStCLFNBQVMsZUFBZSxFQUFFO0FBQ3pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCO0FBQ3ZCLGlCQUFpQjtBQUNqQjtBQUNBLCtCQUErQixTQUFTLDhCQUE4QixFQUFFO0FBQ3hFLCtCQUErQixTQUFTLG9CQUFvQixFQUFFO0FBQzlEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCO0FBQ3ZCLGlCQUFpQjtBQUNqQjtBQUNBLCtCQUErQixTQUFTLDZCQUE2QixFQUFFO0FBQ3ZFLCtCQUErQixTQUFTLHFCQUFxQixFQUFFO0FBQy9EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsU0FBUywwQkFBMEIsRUFBRTtBQUN0RDtBQUNBO0FBQ0E7QUFDQSxxQkFBcUIsU0FBUywrQkFBK0IsRUFBRTtBQUMvRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCLFNBQVMsa0NBQWtDLEVBQUU7QUFDMUU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0I7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQjtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQjtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0I7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQSw2QkFBNkIsU0FBUyxzQ0FBc0MsRUFBRTtBQUM5RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQjtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0I7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQjtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQjtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQjtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQjtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQjtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0I7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQjtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0I7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCLFNBQVMsNEJBQTRCLEVBQUU7QUFDcEU7QUFDQTtBQUNBO0FBQ0EsaUNBQWlDLFNBQVMsNEJBQTRCLEVBQUU7QUFDeEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1Q0FBdUM7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVDQUF1QztBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCLFNBQVMsOEJBQThCLEVBQUU7QUFDOUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCO0FBQ3ZCO0FBQ0E7QUFDQSx5QkFBeUIscUNBQXFDLFdBQVcsRUFBRTtBQUMzRTtBQUNBO0FBQ0E7QUFDQSxvQ0FBb0M7QUFDcEMsMkJBQTJCO0FBQzNCO0FBQ0E7QUFDQSxvQ0FBb0M7QUFDcEMsMkJBQTJCO0FBQzNCO0FBQ0E7QUFDQSxvQ0FBb0M7QUFDcEMsMkJBQTJCO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUIsU0FBUyxzQ0FBc0MsRUFBRTtBQUMxRTtBQUNBO0FBQ0E7QUFDQSw2QkFBNkIsU0FBUyw0QkFBNEIsRUFBRTtBQUNwRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlDQUFpQztBQUNqQztBQUNBLCtDQUErQyxTQUFTLGNBQWMsRUFBRTtBQUN4RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1DQUFtQztBQUNuQywrQ0FBK0MsU0FBUyxhQUFhLEVBQUU7QUFDdkU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUNBQWlDO0FBQ2pDO0FBQ0EsK0NBQStDLFNBQVMsZUFBZSxFQUFFO0FBQ3pFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUNBQW1DO0FBQ25DLCtDQUErQyxTQUFTLGFBQWEsRUFBRTtBQUN2RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCO0FBQzVCLG1CQUFtQjtBQUNuQjtBQUNBO0FBQ0EscUJBQXFCLDZCQUE2QixtQkFBbUIsRUFBRTtBQUN2RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0NBQW9DLGdCQUFnQjtBQUNwRCwyQkFBMkI7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QjtBQUM1QixtQkFBbUI7QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QjtBQUM1QixtQkFBbUI7QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwiZmlsZSI6ImJ1bmRsZS4zZjM4YjY0ODhkNzZmYzdiMjNiMC5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiPHRlbXBsYXRlPlxyXG4gICAgPFBhZ2UgY2xhc3M9XCJwYWdlXCI+XHJcbiAgICAgICAgPEFjdGlvbkJhciAgYmFja2dyb3VuZENvbG9yPVwiI2ZmMzMwMFwiIGZsYXQ9XCJ0cnVlXCIgIEB0YXA9XCJsb2dvdXRcIj5cclxuICAgICAgICAgICAgPExhYmVsIGNsYXNzPVwiYWN0aW9uLWJhci10aXRsZVwiIDp0ZXh0PVwic2VsZWN0ZWRUYWI9PTA/J0hvbWUnOiBqdWR1bCBcIj48L0xhYmVsPlxyXG4gICAgICAgIDwvQWN0aW9uQmFyPlxyXG4gIDxCb3R0b21OYXZpZ2F0aW9uIGJhY2tncm91bmRDb2xvcj1cIiMwMDAwMDBcIj5cclxuICAgICAgICA8VGFiU3RyaXA+XHJcbiAgICAgICAgICAgIDxUYWJTdHJpcEl0ZW0gOmNsYXNzPVwic2VsZWN0ZWRUYWI9PTA/J2FjdGl2ZSc6JydcIiBAdGFwPVwiaG9tZVwiPlxyXG4gICAgICAgICAgICAgICAgPEltYWdlIHNyYz1cIn4vaW1hZ2VzL25hdmhvbWUucG5nXCI+PC9JbWFnZT5cclxuICAgICAgICAgICAgICAgIDxMYWJlbCB0ZXh0PVwiSG9teVwiPjwvTGFiZWw+XHJcbiAgICAgICAgICAgIDwvVGFiU3RyaXBJdGVtPlxyXG4gICAgICAgICAgICA8VGFiU3RyaXBJdGVtIDpjbGFzcz1cInNlbGVjdGVkVGFiPT0xPydhY3RpdmUnOicnXCIgQHRhcD1cIm9yZGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwifi9pbWFnZXMvbmF2b3JkZXJzLnBuZ1wiPjwvSW1hZ2U+XHJcbiAgICAgICAgICAgICAgICA8TGFiZWwgdGV4dD1cIk9yZGVyXCI+PC9MYWJlbD5cclxuICAgICAgICAgICAgPC9UYWJTdHJpcEl0ZW0+XHJcbiAgICAgICAgICAgIDxUYWJTdHJpcEl0ZW0gOmNsYXNzPVwic2VsZWN0ZWRUYWI9PTI/J2FjdGl2ZSc6JydcIiBAdGFwPVwiY2hhdFwiPlxyXG4gICAgICAgICAgICAgICAgPEltYWdlIHNyYz1cIn4vaW1hZ2VzL25hdnVzLnBuZ1wiPjwvSW1hZ2U+XHJcbiAgICAgICAgICAgICAgICA8TGFiZWwgdGV4dD1cIkNoYXRcIj48L0xhYmVsPlxyXG4gICAgICAgICAgICA8L1RhYlN0cmlwSXRlbT5cclxuICAgICAgICAgICAgPFRhYlN0cmlwSXRlbSA6Y2xhc3M9XCJzZWxlY3RlZFRhYj09Mz8nYWN0aXZlJzonJ1wiIEB0YXA9XCJiZWxhbmphYW5cIj5cclxuICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9XCJ+L2ltYWdlcy9uYXZjYXJ0LnBuZ1wiPjwvSW1hZ2U+XHJcbiAgICAgICAgICAgICAgICA8TGFiZWwgdGV4dD1cIkJlbGFuamFhblwiPjwvTGFiZWw+XHJcbiAgICAgICAgICAgIDwvVGFiU3RyaXBJdGVtPlxyXG4gICAgICAgICAgICA8VGFiU3RyaXBJdGVtIDpjbGFzcz1cInNlbGVjdGVkVGFiPT00PydhY3RpdmUnOicnXCIgQHRhcD1cInBlbmdhdHVyYW5cIj5cclxuICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9XCJ+L2ltYWdlcy9uYXZzZXQucG5nXCI+PC9JbWFnZT5cclxuICAgICAgICAgICAgICAgIDxMYWJlbCB0ZXh0PVwiUGVuZ2F0dXJhblwiPjwvTGFiZWw+XHJcbiAgICAgICAgICAgIDwvVGFiU3RyaXBJdGVtPlxyXG4gICAgICAgIDwvVGFiU3RyaXA+XHJcblxyXG4gICAgICAgIDxUYWJDb250ZW50SXRlbT5cclxuICAgICAgICAgICAgPFNjcm9sbFZpZXcgb3JpZW50YXRpb249XCJ2ZXJ0aWNhbFwiPlxyXG4gICAgICAgICAgICA8R3JpZExheW91dCByb3dzPVwiKiwqLCosYXV0byxhdXRvLGF1dG9cIj5cclxuICAgICAgICAgICAgICA8U3RhY2tMYXlvdXQgIHJvdz1cIjBcIiBwYWRkaW5nTGVmdD1cIjEwXCIgcGFkZGluZ1JpZ2h0PVwiMTBcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmdCb3R0b209XCIyNVwiIG1hcmdpblRvcD1cIjBcIiBiYWNrZ3JvdW5kQ29sb3I9XCIjZmYzMzAwXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgIGhlaWdodD1cIjEwJVwiIHdpZHRoPVwiMTAwJVwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3RyZXRjaD1cImFzcGVjdEZpdFwiIGNsYXNzPVwiYWxidW0taW1hZ2VcIj4gIFxyXG5cclxuICAgICAgICAgICAgICA8L1N0YWNrTGF5b3V0PlxyXG5cclxuICAgICAgICAgICAgICAgIDxTdGFja0xheW91dCAgcm93PVwiMVwiIHBhZGRpbmdMZWZ0PVwiMjVcIiBwYWRkaW5nUmlnaHQ9XCIyNVwiIHBhZGRpbmdUb3A9XCI1XCJcclxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nQm90dG9tPVwiMjVcIiBtYXJnaW5Ub3A9XCItMjBcIiBiYWNrZ3JvdW5kQ29sb3I9XCIjZmZmZmZmXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzPVwiMTVcIiBoZWlnaHQ9XCIxMCVcIiB3aWR0aD1cIjkwJVwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3RyZXRjaD1cImFzcGVjdEZpdFwiIGNsYXNzPVwiYWxidW0taW1hZ2VcIj5cclxuICAgICAgICAgICAgICAgICAgICA8R3JpZExheW91dCBjb2x1bW5zPVwiKiwqLCpcIiByb3dzPVwiKiwqLCpcIj5cclxuICAgICAgICAgICAgICAgICAgICA8SW1hZ2UgY29sPVwiMFwiIHJvdz1cIjBcIiAgc3JjPVwifi9pbWFnZXMvbG9jYXRpb24ucG5nXCIgc3RyZXRjaD1cImFzcGVjdEZpdFwiIGhvcml6b250YWxBbGlnbm1lbnQ9XCJjZW50ZXJcIiB3aWR0aD1cIjEwMHB4XCI+PC9JbWFnZT4gICAgXHJcbiAgICAgICAgICAgICAgICAgICAgIDxMYWJlbCBjb2w9XCIxXCIgcm93PVwiMFwiIGNsYXNzPVwiZm9udC13ZWlnaHQtYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCIxNlwiIGNvbG9yPVwiIzUyNTE1MVwiIHRleHQ9XCJNYWphbGF5YVwiIGhvcml6b250YWxBbGlnbm1lbnQ9XCJsZWZ0XCIgdmVydGljYWxBbGlnbm1lbnQ9XCJjZW50ZXJcIj48L0xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbWFnZSBjb2w9XCIyXCIgcm93PVwiMFwiICBzcmM9XCJ+L2ltYWdlcy9sb2dvLnBuZ1wiIHN0cmV0Y2g9XCJhc3BlY3RGaXRcIiBob3Jpem9udGFsQWxpZ25tZW50PVwiY2VudGVyXCI+PC9JbWFnZT4gICAgXHJcbiAgICAgICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9XCJ+L2ltYWdlcy9kZXBvc2l0LnBuZ1wiIHJvdz1cIjFcIiBjb2w9XCIwXCIgc3RyZXRjaD1cImFzcGVjdEZpdFwiPjwvSW1hZ2U+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwifi9pbWFnZXMvcG9zdHBhaWQucG5nXCIgIHJvdz1cIjFcIiBjb2w9XCIxXCIgc3RyZXRjaD1cImFzcGVjdEZpdFwiPjwvSW1hZ2U+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwifi9pbWFnZXMvdGFyaWt0dW5haS5wbmdcIiAgcm93PVwiMVwiIGNvbD1cIjJcIiBzdHJldGNoPVwiYXNwZWN0Rml0XCI+PC9JbWFnZT5cclxuICAgICAgICAgICAgICAgICAgICA8TGFiZWwgY29sPVwiMFwiIHJvdz1cIjJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiMTJcIiBjb2xvcj1cIiM1MjUxNTFcIiB0ZXh0PVwiVGFidW5nYW4gU2FtcGFoXCIgdGV4dEFsaWdubWVudD1cImNlbnRlclwiPjwvTGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPExhYmVsIGNvbD1cIjFcIiByb3c9XCIyXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCIxMlwiIGNvbG9yPVwiIzUyNTE1MVwiIHRleHQ9XCJUb3AgVXAvU2V0b3JcIiB0ZXh0QWxpZ25tZW50PVwiY2VudGVyXCI+PC9MYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgPExhYmVsIGNvbD1cIjJcIiByb3c9XCIyXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCIxMlwiIGNvbG9yPVwiIzUyNTE1MVwiIHRleHQ9XCJUYXJpayBUdW5haVwiIHRleHRBbGlnbm1lbnQ9XCJjZW50ZXJcIj48L0xhYmVsPiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDwvR3JpZExheW91dD4gICAgICAgXHJcbiAgICAgICAgICAgICAgICA8L1N0YWNrTGF5b3V0PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgPFN0YWNrTGF5b3V0ICByb3c9XCIyXCIgcGFkZGluZ0xlZnQ9XCIxMFwiIHBhZGRpbmdSaWdodD1cIjEwXCIgcGFkZGluZ1RvcD1cIjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmdCb3R0b209XCI1XCIgbWFyZ2luVG9wPVwiMTBcIiBiYWNrZ3JvdW5kQ29sb3I9XCIjZjhmOGY4XCIgXHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzPVwiMTVcIiBoZWlnaHQ9XCIzNSVcIiB3aWR0aD1cIjkwJVwiPlxyXG4gICAgICAgICAgICAgICAgPEdyaWRMYXlvdXQgY29sdW1ucz1cIiosKiwqLCpcIiByb3dzPVwiKiwqLCosKlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgPEltYWdlIHNyYz1cIn4vaW1hZ2VzL3B1bHNhLnBuZ1wiIHJvdz1cIjBcIiBjb2w9XCIwXCIgc3RyZXRjaD1cImFzcGVjdEZpdFwiPjwvSW1hZ2U+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwifi9pbWFnZXMvcGFrZXRkYXRhLnBuZ1wiICByb3c9XCIwXCIgY29sPVwiMVwiIHN0cmV0Y2g9XCJhc3BlY3RGaXRcIj48L0ltYWdlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgPEltYWdlIHNyYz1cIn4vaW1hZ2VzL3BsbnBhc2NhLnBuZ1wiICByb3c9XCIwXCIgY29sPVwiMlwiIHN0cmV0Y2g9XCJhc3BlY3RGaXRcIj48L0ltYWdlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgPEltYWdlIHNyYz1cIn4vaW1hZ2VzL3Bvc3RwYWlkLnBuZ1wiICByb3c9XCIwXCIgY29sPVwiM1wiIHN0cmV0Y2g9XCJhc3BlY3RGaXRcIj48L0ltYWdlPlxyXG4gICAgICAgICAgICAgICAgICAgPExhYmVsIGNvbD1cIjBcIiByb3c9XCIxXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cIjEyXCIgY29sb3I9XCIjNTI1MTUxXCIgdGV4dD1cIlB1bHNhL1ZvdWNoZXJcIiB0ZXh0QWxpZ25tZW50PVwiY2VudGVyXCI+PC9MYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8TGFiZWwgY29sPVwiMVwiIHJvdz1cIjFcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cIjEyXCIgY29sb3I9XCIjNTI1MTUxXCIgdGV4dD1cIlBha2V0IERhdGFcIiB0ZXh0QWxpZ25tZW50PVwiY2VudGVyXCI+PC9MYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgPExhYmVsIGNvbD1cIjJcIiByb3c9XCIxXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCIxMlwiIGNvbG9yPVwiIzUyNTE1MVwiIHRleHQ9XCJQTE4vVG9rZW5cIiB0ZXh0QWxpZ25tZW50PVwiY2VudGVyXCI+PC9MYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgPExhYmVsIGNvbD1cIjNcIiByb3c9XCIxXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCIxMlwiIGNvbG9yPVwiIzUyNTE1MVwiIHRleHQ9XCJQYXNjYSBCYXlhclwiIHRleHRBbGlnbm1lbnQ9XCJjZW50ZXJcIj48L0xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwifi9pbWFnZXMvZm9vZC5wbmdcIiByb3c9XCIyXCIgY29sPVwiMFwiIHN0cmV0Y2g9XCJhc3BlY3RGaXRcIj48L0ltYWdlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgPEltYWdlIHNyYz1cIn4vaW1hZ2VzL2RyaXZlci5wbmdcIiAgcm93PVwiMlwiIGNvbD1cIjFcIiBzdHJldGNoPVwiYXNwZWN0Rml0XCI+PC9JbWFnZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9XCJ+L2ltYWdlcy9ncm9zaXIucG5nXCIgIHJvdz1cIjJcIiBjb2w9XCIyXCIgc3RyZXRjaD1cImFzcGVjdEZpdFwiPjwvSW1hZ2U+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwifi9pbWFnZXMvY2FyZ28ucG5nXCIgIHJvdz1cIjJcIiBjb2w9XCIzXCIgc3RyZXRjaD1cImFzcGVjdEZpdFwiPjwvSW1hZ2U+XHJcbiAgICAgICAgICAgICAgICAgICA8TGFiZWwgY29sPVwiMFwiIHJvdz1cIjNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiMTJcIiBjb2xvcj1cIiM1MjUxNTFcIiB0ZXh0PVwiRm9vZFwiIHRleHRBbGlnbm1lbnQ9XCJjZW50ZXJcIj48L0xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxMYWJlbCBjb2w9XCIxXCIgcm93PVwiM1wiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiMTJcIiBjb2xvcj1cIiM1MjUxNTFcIiB0ZXh0PVwiRHJpdmVyL0t1cmlyXCIgdGV4dEFsaWdubWVudD1cImNlbnRlclwiPjwvTGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgIDxMYWJlbCBjb2w9XCIyXCIgcm93PVwiM1wiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiMTJcIiBjb2xvcj1cIiM1MjUxNTFcIiB0ZXh0PVwiR3Jvc2lyXCIgdGV4dEFsaWdubWVudD1cImNlbnRlclwiPjwvTGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgIDxMYWJlbCBjb2w9XCIzXCIgcm93PVwiM1wiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiMTJcIiBjb2xvcj1cIiM1MjUxNTFcIiB0ZXh0PVwiQ2FyZ29cIiB0ZXh0QWxpZ25tZW50PVwiY2VudGVyXCI+PC9MYWJlbD5cclxuICAgICAgICAgICAgICAgIDwvR3JpZExheW91dD5cclxuICAgICAgICA8L1N0YWNrTGF5b3V0PlxyXG4gICAgICAgICAgICA8U3RhY2tMYXlvdXQgcm93PVwiM1wiICBoZWlnaHQ9XCIzNSVcIiBwYWRkaW5nTGVmdD1cIjE1XCIgcGFkZGluZ1JpZ2h0PVwiMTVcIiBtYXJnaW5Ub3A9XCIxMFwiPlx0XHRcclxuXHRcdFx0XHJcbiAgICAgICAgICAgIDxTY3JvbGxWaWV3IG9yaWVudGF0aW9uPVwiaG9yaXpvbnRhbFwiPlxyXG4gICAgPFN0YWNrTGF5b3V0IG9yaWVudGF0aW9uPVwiaG9yaXpvbnRhbFwiPlxyXG4gICAgICA8U3RhY2tMYXlvdXQ+XHJcbiAgICAgICAgPEltYWdlIHNyYz1cIn4vaW1hZ2VzL2Jpa2VkYXkucG5nXCIgYm9yZGVyUmFkaXVzPVwiMTVcIiBoZWlnaHQ9XCIyNSVcIiBtYXJnaW49XCIxMFwiIHN0cmV0Y2g9XCJhc3BlY3RGaXRcIj48L0ltYWdlPlxyXG4gICAgICA8L1N0YWNrTGF5b3V0PiAgXHJcbiAgICAgIDxTdGFja0xheW91dD5cclxuICAgICAgICA8SW1hZ2Ugc3JjPVwifi9pbWFnZXMvc2FtcGFoLmpwZ1wiIGJvcmRlclJhZGl1cz1cIjE1XCIgaGVpZ2h0PVwiMjUlXCIgbWFyZ2luPVwiMTBcIiAgc3RyZXRjaD1cImFzcGVjdEZpdFwiPjwvSW1hZ2U+XHJcbiAgICAgIDwvU3RhY2tMYXlvdXQ+ICBcclxuICAgICAgPFN0YWNrTGF5b3V0PlxyXG4gICAgICAgIDxJbWFnZSBzcmM9XCJ+L2ltYWdlcy9hZ2VucHVsc2EuanBnXCIgYm9yZGVyUmFkaXVzPVwiMTVcIiBoZWlnaHQ9XCIyNSVcIiBtYXJnaW49XCIxMFwiICBzdHJldGNoPVwiYXNwZWN0Rml0XCI+PC9JbWFnZT5cclxuICAgICAgPC9TdGFja0xheW91dD4gIFxyXG4gICAgICBcclxuICAgIDwvU3RhY2tMYXlvdXQ+XHJcbiAgPC9TY3JvbGxWaWV3PiBcclxuXHRcdFx0PC9TdGFja0xheW91dD4gICBcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8L0dyaWRMYXlvdXQ+XHJcbiAgICAgICAgICAgIDwvU2Nyb2xsVmlldz5cclxuICAgICAgICA8L1RhYkNvbnRlbnRJdGVtPlxyXG5cclxuICAgICAgICA8VGFiQ29udGVudEl0ZW0+XHJcbiAgICAgICAgICAgIDxTdGFja0xheW91dD5cclxuICAgICAgICAgICAgICAgIDxHcmlkTGF5b3V0IHJvd3M9XCIqLGF1dG8sKixhdXRvLCBhdXRvXCI+XHJcbiAgPEltYWdlIHNyYz1cImh0dHBzOi8vczdkMi5zY2VuZTcuY29tL2lzL2ltYWdlL1RXQ05ld3MvMTAzMV9uY19zdW5ueV93ZWF0aGVyXzItMVwiIGlvc092ZXJmbG93U2FmZUFyZWE9XCJ0cnVlXCIgc3RyZXRjaD1cImFzcGVjdEZpbGxcIiByb3dTcGFuPVwiNVwiPjwvSW1hZ2U+XHJcbiAgPFN0YWNrTGF5b3V0IHJvdz1cIjFcIiBjbGFzcz1cInRleHQtY2VudGVyXCI+XHJcbiAgICA8TGFiZWwgdGV4dD1cIkpha2FydGFcIiBjbGFzcz1cImgxXCIgY29sb3I9XCIjZmZmZmZmXCI+PC9MYWJlbD5cclxuICAgIDxMYWJlbCB0ZXh0PVwiQ2xvdWR5XCIgIGNsYXNzPVwiaDJcIiBjb2xvcj1cIiNmZmZmZmZcIj48L0xhYmVsPlxyXG4gICAgPExhYmVsIHRleHQ9XCIzM1wiICBjbGFzcz1cImgxXCIgY29sb3I9XCIjZmZmZmZmXCI+PC9MYWJlbD5cclxuICA8L1N0YWNrTGF5b3V0PlxyXG4gIDxTY3JvbGxWaWV3IHJvdz1cIjNcIiBvcmllbnRhdGlvbj1cImhvcml6b250YWxcIj5cclxuICAgIDxTdGFja0xheW91dCBvcmllbnRhdGlvbj1cImhvcml6b250YWxcIj5cclxuICAgICAgPFN0YWNrTGF5b3V0IHN0eWxlPVwiY29sb3I6IHdoaXRlOyBtYXJnaW46IDEwOyBmb250LXNpemU6IDEzO1wiIGNsYXNzPVwidGV4dC1jZW50ZXJcIj5cclxuICAgICAgICA8TGFiZWwgdGV4dD1cIk5vd1wiPjwvTGFiZWw+XHJcbiAgICAgICAgPEltYWdlIHNyYz1cImh0dHBzOi8vY2RuLnBpeGFiYXkuY29tL3Bob3RvLzIwMTUvMTIvMDMvMTUvNDMvc3VuLTEwNzUxNTRfOTYwXzcyMC5wbmdcIiBoZWlnaHQ9XCIyMFwiIG1hcmdpbj1cIjVcIj48L0ltYWdlPlxyXG4gICAgICAgIDxMYWJlbCB0ZXh0PVwiNzlcIj48L0xhYmVsPlxyXG4gICAgICA8L1N0YWNrTGF5b3V0PiAgXHJcbiAgICAgIDxTdGFja0xheW91dCBzdHlsZT1cImNvbG9yOiB3aGl0ZTsgbWFyZ2luOiAxMDsgZm9udC1zaXplOiAxMztcIiBjbGFzcz1cInRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgPExhYmVsIHRleHQ9XCIxMGFtXCI+PC9MYWJlbD5cclxuICAgICAgICA8SW1hZ2Ugc3JjPVwiaHR0cHM6Ly9jZG4ucGl4YWJheS5jb20vcGhvdG8vMjAxNS8xMi8wMy8xNS80My9zdW4tMTA3NTE1NF85NjBfNzIwLnBuZ1wiIGhlaWdodD1cIjIwXCIgbWFyZ2luPVwiNVwiPjwvSW1hZ2U+XHJcbiAgICAgICAgPExhYmVsIHRleHQ9XCI4MVwiPjwvTGFiZWw+XHJcbiAgICAgIDwvU3RhY2tMYXlvdXQ+ICBcclxuICAgIDwvU3RhY2tMYXlvdXQ+XHJcbiAgPC9TY3JvbGxWaWV3PlxyXG48L0dyaWRMYXlvdXQ+XHJcbiAgICAgICAgICAgIDwvU3RhY2tMYXlvdXQ+XHJcbiAgICAgICAgPC9UYWJDb250ZW50SXRlbT5cclxuICAgICAgICA8VGFiQ29udGVudEl0ZW0+XHJcbiAgICAgICAgICAgIDxTdGFja0xheW91dD5cclxuICAgICAgICAgICAgICAgIDxMYWJlbCB0ZXh0PVwiQm90dG9tIE5hdiBDb250ZW50IDNcIiBjbGFzcz1cImgxIHRleHQtY2VudGVyIHAtdC0yMFwiPjwvTGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8TGFiZWwgY2xhc3M9XCJmYXNcIiB0ZXh0V3JhcD1cInRydWVcIj5cclxuICAgIDxGb3JtYXR0ZWRTdHJpbmc+XHJcbiAgICAgICAgPFNwYW4gdGV4dD1cIiYjeGYwNTM7XCIgZm9udEF0dHJpYnV0ZXM9XCJCb2xkXCI+PC9TcGFuPlxyXG4gICAgPC9Gb3JtYXR0ZWRTdHJpbmc+XHJcbjwvTGFiZWw+XHJcbiAgICAgICAgICAgIDwvU3RhY2tMYXlvdXQ+XHJcbiAgICAgICAgPC9UYWJDb250ZW50SXRlbT5cclxuXHJcbiAgICAgICAgPFRhYkNvbnRlbnRJdGVtPlxyXG4gICAgICAgICAgICA8U3RhY2tMYXlvdXQ+XHJcbiAgICAgICAgICAgICAgICA8TGFiZWwgdGV4dD1cIkJvdHRvbSBOYXYgQ29udGVudCA0XCIgY2xhc3M9XCJoMSB0ZXh0LWNlbnRlciBwLXQtMjBcIj48L0xhYmVsPlxyXG4gICAgICAgICAgICA8L1N0YWNrTGF5b3V0PlxyXG4gICAgICAgIDwvVGFiQ29udGVudEl0ZW0+XHJcblxyXG4gICAgICAgIDxUYWJDb250ZW50SXRlbT5cclxuICAgICAgICAgICAgPFN0YWNrTGF5b3V0PlxyXG4gICAgICAgICAgICAgICAgPExhYmVsIHRleHQ9XCJCb3R0b20gTmF2IENvbnRlbnQgNVwiIGNsYXNzPVwiaDEgdGV4dC1jZW50ZXIgcC10LTIwXCI+PC9MYWJlbD5cclxuICAgICAgICAgICAgPC9TdGFja0xheW91dD5cclxuICAgICAgICA8L1RhYkNvbnRlbnRJdGVtPlxyXG4gICAgPC9Cb3R0b21OYXZpZ2F0aW9uPlxyXG5cclxuXHJcbiAgICA8L1BhZ2U+XHJcbjwvdGVtcGxhdGU+XHJcblxyXG48c2NyaXB0PlxyXG4gICAgaW1wb3J0IExvZ2luIGZyb20gXCIuL0xvZ2luXCI7XHJcbiAgICBpbXBvcnQgeyBtYXBTdGF0ZSB9IGZyb20gJ3Z1ZXgnO1xyXG4gICAgaW1wb3J0IEl0ZW0gZnJvbSBcIi4vY3VzdG9tL2l0ZW1cIjtcclxuXHRpbXBvcnQgQ2F0ZWdvcnkgZnJvbSBcIi4vY3VzdG9tL2NhdGVnb3J5XCI7XHJcbiAgICBleHBvcnQgZGVmYXVsdCB7XHJcbiAgICAgICAgY29tcG9uZW50czoge1xyXG5cdFx0SXRlbSxcclxuXHRcdENhdGVnb3J5XHJcblx0ICAgIH0sXHJcbiAgICAgICAgZGF0YSgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC8vbWVzc2FnZTogXCJXZWxjb21lLi5cIixcclxuICAgICAgICAgICAgICAgIHNhbGRvOjAsXHJcbiAgICAgICAgICAgICAgICB1c2VyRGF0YTp0aGlzLiRzdG9yZS5zdGF0ZS51c2VyLFxyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRUYWI6IDAsXHJcbiAgICAgICAgICAgICAgICBzZWxlY3RlZFRhYnZpZXc6IDAsXHJcbiAgICAgICAgICAgICAgICBpdGVtczogW3tcclxuXHRcdFx0XHRuYW1lOiBcIk1hbmlsYSBVbHRpbWF0ZSBUb21ic3RvbmUgQnVyZ2VyXCIsXHJcblx0XHRcdFx0Y292ZXI6IFwifi9hc3NldHMvaW1hZ2VzL2Zvb2QvYnVyZ2VyNjQwLmpwZ1wiLFxyXG5cdFx0XHRcdGltYWdlczogW1xyXG5cdFx0XHRcdFx0XHR7c3JjOiBcIn4vYXNzZXRzL2ltYWdlcy9mb29kL2J1cmdlci9idXJnZXIxLmpwZ1wifSxcclxuXHRcdFx0XHRcdFx0e3NyYzogXCJ+L2Fzc2V0cy9pbWFnZXMvZm9vZC9idXJnZXIvYnVyZ2VyMi5qcGdcIn0sXHJcblx0XHRcdFx0XHRcdHtzcmM6IFwifi9hc3NldHMvaW1hZ2VzL2Zvb2QvYnVyZ2VyL2J1cmdlcjMuanBnXCJ9LFxyXG5cdFx0XHRcdFx0XHR7c3JjOiBcIn4vYXNzZXRzL2ltYWdlcy9mb29kL2J1cmdlci9idXJnZXI0LmpwZ1wifSxcclxuXHRcdFx0XHRcdFx0e3NyYzogXCJ+L2Fzc2V0cy9pbWFnZXMvZm9vZC9idXJnZXIvYnVyZ2VyNS5qcGdcIn0sXHJcblx0XHRcdFx0XHRcdHtzcmM6IFwifi9hc3NldHMvaW1hZ2VzL2Zvb2QvYnVyZ2VyL2J1cmdlcjYuanBnXCJ9XHJcblx0XHRcdFx0XHRdLFxyXG5cdFx0XHRcdGNhdGVnb3J5OiBcIkJ1cmdlclwiLFxyXG5cdFx0XHRcdGNhdGVnb3J5VGFnOiBcIiMyRDlDREJcIixcclxuXHRcdFx0XHRwcmljZTogXCIzMDAuMDBcIixcclxuXHRcdFx0XHRsaWtlczogOTg3LFxyXG5cdFx0XHRcdGlzTGlrZTogZmFsc2UsXHJcblx0XHRcdFx0aXNGYXZvcml0ZTogdHJ1ZSxcclxuXHRcdFx0XHRjb21tZW50czogMTMsXHJcblx0XHRcdFx0cmF0aW5nOiBcIjQuNVwiLFxyXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiYVwiLFxyXG4gICAgICAgICAgICAgICAganVkdWw6XCJIb21lXCJcclxuXHRcdFx0fSxcclxuXHRcdFx0e1xyXG5cdFx0XHRcdG5hbWU6IFwiUXVlem9uIENob2NvbGF0ZSBNYXJibGUgUGFuY2FrZVwiLFxyXG5cdFx0XHRcdGNvdmVyOiBcIn4vYXNzZXRzL2ltYWdlcy9mb29kL3BhbmNha2U2NDAuanBnXCIsXHJcblx0XHRcdFx0aW1hZ2VzOiBbXHJcblx0XHRcdFx0XHR7c3JjOiBcIn4vYXNzZXRzL2ltYWdlcy9mb29kL3BhbmNha2UvcGFuY2FrZTEuanBnXCJ9LFxyXG5cdFx0XHRcdFx0e3NyYzogXCJ+L2Fzc2V0cy9pbWFnZXMvZm9vZC9wYW5jYWtlL3BhbmNha2UyLmpwZ1wifSxcclxuXHRcdFx0XHRcdHtzcmM6IFwifi9hc3NldHMvaW1hZ2VzL2Zvb2QvcGFuY2FrZS9wYW5jYWtlMy5qcGdcIn0sXHJcblx0XHRcdFx0XHR7c3JjOiBcIn4vYXNzZXRzL2ltYWdlcy9mb29kL3BhbmNha2UvcGFuY2FrZTQuanBnXCJ9LFxyXG5cdFx0XHRcdFx0e3NyYzogXCJ+L2Fzc2V0cy9pbWFnZXMvZm9vZC9wYW5jYWtlL3BhbmNha2U1LmpwZ1wifSxcclxuXHRcdFx0XHRcdHtzcmM6IFwifi9hc3NldHMvaW1hZ2VzL2Zvb2QvcGFuY2FrZS9wYW5jYWtlNi5qcGdcIn1cclxuXHRcdFx0XHRdLFxyXG5cdFx0XHRcdGNhdGVnb3J5OiBcIlBhbmNha2VcIixcclxuXHRcdFx0XHRjYXRlZ29yeVRhZzogXCIjZTRjZTBkXCIsXHJcblx0XHRcdFx0cHJpY2U6IFwiMjMwLjAwXCIsXHJcblx0XHRcdFx0bGlrZXM6IDg5MSxcclxuXHRcdFx0XHRpc0xpa2U6IHRydWUsXHJcblx0XHRcdFx0aXNGYXZvcml0ZTogdHJ1ZSxcclxuXHRcdFx0XHRjb21tZW50czogNyxcclxuXHRcdFx0XHRyYXRpbmc6IFwiNC4wXCIsXHJcblx0XHRcdFx0ZGVzY3JpcHRpb246IFwiYVwiXHJcblx0XHRcdH0sXHJcblx0XHRcdHtcclxuXHRcdFx0XHRuYW1lOiBcIkJpbm9uZG8gQmxhY2sgRm9yZXN0IENha2VcIixcclxuXHRcdFx0XHRjb3ZlcjogXCJ+L2Fzc2V0cy9pbWFnZXMvZm9vZC9jYWtlNjQwLmpwZ1wiLFxyXG5cdFx0XHRcdGltYWdlczogW1xyXG5cdFx0XHRcdFx0e3NyYzogXCJ+L2Fzc2V0cy9pbWFnZXMvZm9vZC9jYWtlL2Nha2UxLmpwZ1wifSxcclxuXHRcdFx0XHRcdHtzcmM6IFwifi9hc3NldHMvaW1hZ2VzL2Zvb2QvY2FrZS9jYWtlMi5qcGdcIn0sXHJcblx0XHRcdFx0XHR7c3JjOiBcIn4vYXNzZXRzL2ltYWdlcy9mb29kL2Nha2UvY2FrZTMuanBnXCJ9LFxyXG5cdFx0XHRcdFx0e3NyYzogXCJ+L2Fzc2V0cy9pbWFnZXMvZm9vZC9jYWtlL2Nha2U0LmpwZ1wifVxyXG5cdFx0XHRcdF0sXHJcblx0XHRcdFx0Y2F0ZWdvcnk6IFwiQ2FrZVwiLFxyXG5cdFx0XHRcdGNhdGVnb3J5VGFnOiBcIiMyN0FFNjBcIixcclxuXHRcdFx0XHRwcmljZTogXCIzMDAuMDBcIixcclxuXHRcdFx0XHRsaWtlczogNzMwLFxyXG5cdFx0XHRcdGlzTGlrZTogdHJ1ZSxcclxuXHRcdFx0XHRpc0Zhdm9yaXRlOiB0cnVlLFxyXG5cdFx0XHRcdGNvbW1lbnRzOiAxMSxcclxuXHRcdFx0XHRyYXRpbmc6IFwiNC4wXCIsXHJcblx0XHRcdFx0ZGVzY3JpcHRpb246IFwiYVwiXHJcblx0XHRcdH0sXHJcblx0XHRcdF0sXHJcblx0XHRcdGNhdGVnb3J5OiBbXHJcblx0XHRcdHtcclxuXHRcdFx0XHRjb3ZlcjogXCJ+L2Fzc2V0cy9pbWFnZXMvZm9vZC9idXJnZXI2NDAuanBnXCIsXHJcblx0XHRcdFx0Y2F0ZWdvcnk6IFwiQlVSR0VSXCIsXHJcblx0XHRcdFx0Y291bnQ6IFwiMTNcIixcclxuXHRcdFx0fSxcclxuXHRcdFx0e1xyXG5cdFx0XHRcdGNvdmVyOiBcIn4vYXNzZXRzL2ltYWdlcy9mb29kL3BhbmNha2U2NDAuanBnXCIsXHJcblx0XHRcdFx0Y2F0ZWdvcnk6IFwiUEFOQ0FLRVwiLFxyXG5cdFx0XHRcdGNvdW50OiBcIjVcIixcclxuXHRcdFx0fSxcclxuXHRcdFx0e1xyXG5cdFx0XHRcdGNvdmVyOiBcIn4vYXNzZXRzL2ltYWdlcy9mb29kL2Nha2U2NDAuanBnXCIsXHJcblx0XHRcdFx0Y2F0ZWdvcnk6IFwiQ0FLRVwiLFxyXG5cdFx0XHRcdGNvdW50OiBcIjlcIixcclxuXHRcdFx0fSxcclxuXHRcdFx0e1xyXG5cdFx0XHRcdGNvdmVyOiBcIn4vYXNzZXRzL2ltYWdlcy9mb29kL2JlZXI2NDAuanBnXCIsXHJcblx0XHRcdFx0Y2F0ZWdvcnk6IFwiQkVFUlwiLFxyXG5cdFx0XHRcdGNvdW50OiBcIjdcIixcclxuXHRcdFx0fSxcclxuXHRcdFxyXG5cdFx0XHRdXHJcblx0XHRcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIGNvbXB1dGVkOntcclxuXHJcbiAgICAgICAgICAgIGl0ZW1zQ2F0ZWdvcnkoKXtcclxuXHRcdFx0cmV0dXJuIHRoaXMuY2F0ZWdvcnkuc2xpY2UoKS5yZXZlcnNlKCk7XHJcblx0XHQgICAgfSxcclxuICAgICAgICAgICAgZ2V0U2FsZG8oKXtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnNhbGRvXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHdlbGNvbWUoKXtcclxuICAgICAgICAgICAgICAgIHJldHVybiBcIk5vIEhQIGFuZGEgXCIgKyB0aGlzLnVzZXJEYXRhLm5vX2hwXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIC4uLm1hcFN0YXRlKFsndXNlcicsJ21lc3NhZ2UnXSlcclxuICAgICAgICB9LFxyXG4gICAgICAgIG1ldGhvZHM6IHtcclxuICAgICAgICBsb2dvdXQoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLiRzdG9yZVxyXG4gICAgICAgICAgICAgICAgICAgIC5kaXNwYXRjaCgnbG9nb3V0JylcclxuICAgICAgICAgICAgICAgICAgICAudGhlbigoKSA9PiB7ICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vdGhpcy5hbGVydChcIlNhbXBhaSBqdW1wYSBsYWdpLi4uXCIpOyAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJG5hdmlnYXRlVG8oTG9naW4sIHsgY2xlYXJIaXN0b3J5OiB0cnVlIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgfSxcclxuICAgICAgICBob21lKCkge1xyXG4gICAgICAgICAgICB0aGlzLnNlbGVjdGVkVGFiID0gMDtcclxuICAgICAgICAgICAgdGhpcy5qdWR1bCA9J0hvbWUnO1xyXG5cdFx0fSxcclxuXHRcdG9yZGVyKCkge1xyXG4gICAgICAgICAgICB0aGlzLnNlbGVjdGVkVGFiID0gMTtcclxuICAgICAgICAgICAgdGhpcy5qdWR1bCA9ICdPcmRlcic7XHJcblx0XHR9LFxyXG5cdFx0Y2hhdCgpIHtcclxuICAgICAgICAgICAgdGhpcy5zZWxlY3RlZFRhYiA9IDI7XHJcbiAgICAgICAgICAgIHRoaXMuanVkdWwgPSAnQ2hhdCc7XHJcblx0XHR9LFxyXG5cdFx0YmVsYW5qYWFuKCkge1xyXG4gICAgICAgICAgICB0aGlzLnNlbGVjdGVkVGFiID0gNDtcclxuICAgICAgICAgICAgdGhpcy5qdWR1bCA9ICdCZWxhbmphYW4nO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgcGVuZ2F0dXJhbigpIHtcclxuICAgICAgICAgICAgdGhpcy5zZWxlY3RlZFRhYiA9IDU7XHJcbiAgICAgICAgICAgIHRoaXMuanVkdWwgPSAnUGVuZ2F0dXJhbidcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuPC9zY3JpcHQ+XHJcblxyXG48c3R5bGU+XHJcbiAgICAubmF2Qm90dG9tIHtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmYzMzAwO1xyXG4gICAgICAgIGJvcmRlci1jb2xvcjogI2ZmMzMwMDtcclxuICAgICAgICBjb2xvcjojZmZmZmZmO1xyXG4gICAgfVxyXG5cclxuQWN0aW9uQmFyIHtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgIH1cclxuXHJcbiAgICAuYWxidW0taW1hZ2Uge1xyXG4gICAgICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICAgICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuICAgICAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XHJcbiAgICB9XHJcblxyXG4gICAgLmhvbWUtcGFuZWwge1xyXG4gICAgICAgIHZlcnRpY2FsLWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgZm9udC1zaXplOiAyMDtcclxuICAgICAgICBtYXJnaW46IDE1O1xyXG4gICAgfVxyXG5cclxuICAgIC5kZXNjcmlwdGlvbi1sYWJlbCB7XHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMTU7XHJcbiAgICB9XHJcblxyXG4gICAgI3NlYXJjaFJvdyB7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogMjA7XHJcbiAgICB9XHJcbjwvc3R5bGU+XHJcbiIsInZhciByZW5kZXIgPSBmdW5jdGlvbigpIHtcbiAgdmFyIF92bSA9IHRoaXNcbiAgdmFyIF9oID0gX3ZtLiRjcmVhdGVFbGVtZW50XG4gIHZhciBfYyA9IF92bS5fc2VsZi5fYyB8fCBfaFxuICByZXR1cm4gX2MoXG4gICAgXCJQYWdlXCIsXG4gICAgeyBzdGF0aWNDbGFzczogXCJwYWdlXCIgfSxcbiAgICBbXG4gICAgICBfYyhcbiAgICAgICAgXCJBY3Rpb25CYXJcIixcbiAgICAgICAge1xuICAgICAgICAgIGF0dHJzOiB7IGJhY2tncm91bmRDb2xvcjogXCIjZmYzMzAwXCIsIGZsYXQ6IFwidHJ1ZVwiIH0sXG4gICAgICAgICAgb246IHsgdGFwOiBfdm0ubG9nb3V0IH1cbiAgICAgICAgfSxcbiAgICAgICAgW1xuICAgICAgICAgIF9jKFwiTGFiZWxcIiwge1xuICAgICAgICAgICAgc3RhdGljQ2xhc3M6IFwiYWN0aW9uLWJhci10aXRsZVwiLFxuICAgICAgICAgICAgYXR0cnM6IHsgdGV4dDogX3ZtLnNlbGVjdGVkVGFiID09IDAgPyBcIkhvbWVcIiA6IF92bS5qdWR1bCB9XG4gICAgICAgICAgfSlcbiAgICAgICAgXSxcbiAgICAgICAgMVxuICAgICAgKSxcbiAgICAgIF9jKFxuICAgICAgICBcIkJvdHRvbU5hdmlnYXRpb25cIixcbiAgICAgICAgeyBhdHRyczogeyBiYWNrZ3JvdW5kQ29sb3I6IFwiIzAwMDAwMFwiIH0gfSxcbiAgICAgICAgW1xuICAgICAgICAgIF9jKFxuICAgICAgICAgICAgXCJUYWJTdHJpcFwiLFxuICAgICAgICAgICAgW1xuICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICBcIlRhYlN0cmlwSXRlbVwiLFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgIGNsYXNzOiBfdm0uc2VsZWN0ZWRUYWIgPT0gMCA/IFwiYWN0aXZlXCIgOiBcIlwiLFxuICAgICAgICAgICAgICAgICAgb246IHsgdGFwOiBfdm0uaG9tZSB9XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBbXG4gICAgICAgICAgICAgICAgICBfYyhcIkltYWdlXCIsIHsgYXR0cnM6IHsgc3JjOiBcIn4vaW1hZ2VzL25hdmhvbWUucG5nXCIgfSB9KSxcbiAgICAgICAgICAgICAgICAgIF9jKFwiTGFiZWxcIiwgeyBhdHRyczogeyB0ZXh0OiBcIkhvbXlcIiB9IH0pXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgIFwiVGFiU3RyaXBJdGVtXCIsXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgY2xhc3M6IF92bS5zZWxlY3RlZFRhYiA9PSAxID8gXCJhY3RpdmVcIiA6IFwiXCIsXG4gICAgICAgICAgICAgICAgICBvbjogeyB0YXA6IF92bS5vcmRlciB9XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBbXG4gICAgICAgICAgICAgICAgICBfYyhcIkltYWdlXCIsIHsgYXR0cnM6IHsgc3JjOiBcIn4vaW1hZ2VzL25hdm9yZGVycy5wbmdcIiB9IH0pLFxuICAgICAgICAgICAgICAgICAgX2MoXCJMYWJlbFwiLCB7IGF0dHJzOiB7IHRleHQ6IFwiT3JkZXJcIiB9IH0pXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgIFwiVGFiU3RyaXBJdGVtXCIsXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgY2xhc3M6IF92bS5zZWxlY3RlZFRhYiA9PSAyID8gXCJhY3RpdmVcIiA6IFwiXCIsXG4gICAgICAgICAgICAgICAgICBvbjogeyB0YXA6IF92bS5jaGF0IH1cbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgIF9jKFwiSW1hZ2VcIiwgeyBhdHRyczogeyBzcmM6IFwifi9pbWFnZXMvbmF2dXMucG5nXCIgfSB9KSxcbiAgICAgICAgICAgICAgICAgIF9jKFwiTGFiZWxcIiwgeyBhdHRyczogeyB0ZXh0OiBcIkNoYXRcIiB9IH0pXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgIFwiVGFiU3RyaXBJdGVtXCIsXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgY2xhc3M6IF92bS5zZWxlY3RlZFRhYiA9PSAzID8gXCJhY3RpdmVcIiA6IFwiXCIsXG4gICAgICAgICAgICAgICAgICBvbjogeyB0YXA6IF92bS5iZWxhbmphYW4gfVxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgX2MoXCJJbWFnZVwiLCB7IGF0dHJzOiB7IHNyYzogXCJ+L2ltYWdlcy9uYXZjYXJ0LnBuZ1wiIH0gfSksXG4gICAgICAgICAgICAgICAgICBfYyhcIkxhYmVsXCIsIHsgYXR0cnM6IHsgdGV4dDogXCJCZWxhbmphYW5cIiB9IH0pXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgIFwiVGFiU3RyaXBJdGVtXCIsXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgY2xhc3M6IF92bS5zZWxlY3RlZFRhYiA9PSA0ID8gXCJhY3RpdmVcIiA6IFwiXCIsXG4gICAgICAgICAgICAgICAgICBvbjogeyB0YXA6IF92bS5wZW5nYXR1cmFuIH1cbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgIF9jKFwiSW1hZ2VcIiwgeyBhdHRyczogeyBzcmM6IFwifi9pbWFnZXMvbmF2c2V0LnBuZ1wiIH0gfSksXG4gICAgICAgICAgICAgICAgICBfYyhcIkxhYmVsXCIsIHsgYXR0cnM6IHsgdGV4dDogXCJQZW5nYXR1cmFuXCIgfSB9KVxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgMVxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgMVxuICAgICAgICAgICksXG4gICAgICAgICAgX2MoXG4gICAgICAgICAgICBcIlRhYkNvbnRlbnRJdGVtXCIsXG4gICAgICAgICAgICBbXG4gICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgIFwiU2Nyb2xsVmlld1wiLFxuICAgICAgICAgICAgICAgIHsgYXR0cnM6IHsgb3JpZW50YXRpb246IFwidmVydGljYWxcIiB9IH0sXG4gICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgX2MoXG4gICAgICAgICAgICAgICAgICAgIFwiR3JpZExheW91dFwiLFxuICAgICAgICAgICAgICAgICAgICB7IGF0dHJzOiB7IHJvd3M6IFwiKiwqLCosYXV0byxhdXRvLGF1dG9cIiB9IH0sXG4gICAgICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgICAgICBfYyhcIlN0YWNrTGF5b3V0XCIsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXRpY0NsYXNzOiBcImFsYnVtLWltYWdlXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICByb3c6IFwiMFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nTGVmdDogXCIxMFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nUmlnaHQ6IFwiMTBcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZ0JvdHRvbTogXCIyNVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW5Ub3A6IFwiMFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiI2ZmMzMwMFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IFwiMTAlXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiBcIjEwMCVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3RyZXRjaDogXCJhc3BlY3RGaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJTdGFja0xheW91dFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0aWNDbGFzczogXCJhbGJ1bS1pbWFnZVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvdzogXCIxXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZ0xlZnQ6IFwiMjVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nUmlnaHQ6IFwiMjVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nVG9wOiBcIjVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nQm90dG9tOiBcIjI1XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luVG9wOiBcIi0yMFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogXCIjZmZmZmZmXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiBcIjE1XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBcIjEwJVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiBcIjkwJVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cmV0Y2g6IFwiYXNwZWN0Rml0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgX2MoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJHcmlkTGF5b3V0XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBhdHRyczogeyBjb2x1bW5zOiBcIiosKiwqXCIsIHJvd3M6IFwiKiwqLCpcIiB9IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX2MoXCJJbWFnZVwiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sOiBcIjBcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3c6IFwiMFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYzogXCJ+L2ltYWdlcy9sb2NhdGlvbi5wbmdcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJldGNoOiBcImFzcGVjdEZpdFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhvcml6b250YWxBbGlnbm1lbnQ6IFwiY2VudGVyXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IFwiMTAwcHhcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9jKFwiTGFiZWxcIiwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0aWNDbGFzczogXCJmb250LXdlaWdodC1ib2xkXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sOiBcIjFcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3c6IFwiMFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcIjE2XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwiIzUyNTE1MVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHQ6IFwiTWFqYWxheWFcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBob3Jpem9udGFsQWxpZ25tZW50OiBcImxlZnRcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2ZXJ0aWNhbEFsaWdubWVudDogXCJjZW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9jKFwiSW1hZ2VcIiwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbDogXCIyXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93OiBcIjBcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM6IFwifi9pbWFnZXMvbG9nby5wbmdcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJldGNoOiBcImFzcGVjdEZpdFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhvcml6b250YWxBbGlnbm1lbnQ6IFwiY2VudGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfYyhcIkltYWdlXCIsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM6IFwifi9pbWFnZXMvZGVwb3NpdC5wbmdcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3c6IFwiMVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbDogXCIwXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RyZXRjaDogXCJhc3BlY3RGaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9jKFwiSW1hZ2VcIiwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYzogXCJ+L2ltYWdlcy9wb3N0cGFpZC5wbmdcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3c6IFwiMVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbDogXCIxXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RyZXRjaDogXCJhc3BlY3RGaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9jKFwiSW1hZ2VcIiwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYzogXCJ+L2ltYWdlcy90YXJpa3R1bmFpLnBuZ1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvdzogXCIxXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sOiBcIjJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJldGNoOiBcImFzcGVjdEZpdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX2MoXCJMYWJlbFwiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sOiBcIjBcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3c6IFwiMlwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcIjEyXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwiIzUyNTE1MVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHQ6IFwiVGFidW5nYW4gU2FtcGFoXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGV4dEFsaWdubWVudDogXCJjZW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9jKFwiTGFiZWxcIiwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbDogXCIxXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93OiBcIjJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogXCIxMlwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcIiM1MjUxNTFcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0OiBcIlRvcCBVcC9TZXRvclwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHRBbGlnbm1lbnQ6IFwiY2VudGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfYyhcIkxhYmVsXCIsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2w6IFwiMlwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvdzogXCIyXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMTJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCIjNTI1MTUxXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGV4dDogXCJUYXJpayBUdW5haVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHRBbGlnbm1lbnQ6IFwiY2VudGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJTdGFja0xheW91dFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvdzogXCIyXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZ0xlZnQ6IFwiMTBcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nUmlnaHQ6IFwiMTBcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nVG9wOiBcIjVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nQm90dG9tOiBcIjVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW5Ub3A6IFwiMTBcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiI2Y4ZjhmOFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogXCIxNVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogXCIzNSVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogXCI5MCVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIkdyaWRMYXlvdXRcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGF0dHJzOiB7IGNvbHVtbnM6IFwiKiwqLCosKlwiLCByb3dzOiBcIiosKiwqLCpcIiB9IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX2MoXCJJbWFnZVwiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjOiBcIn4vaW1hZ2VzL3B1bHNhLnBuZ1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvdzogXCIwXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sOiBcIjBcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJldGNoOiBcImFzcGVjdEZpdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX2MoXCJJbWFnZVwiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjOiBcIn4vaW1hZ2VzL3Bha2V0ZGF0YS5wbmdcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3c6IFwiMFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbDogXCIxXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RyZXRjaDogXCJhc3BlY3RGaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9jKFwiSW1hZ2VcIiwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYzogXCJ+L2ltYWdlcy9wbG5wYXNjYS5wbmdcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3c6IFwiMFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbDogXCIyXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RyZXRjaDogXCJhc3BlY3RGaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9jKFwiSW1hZ2VcIiwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYzogXCJ+L2ltYWdlcy9wb3N0cGFpZC5wbmdcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3c6IFwiMFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbDogXCIzXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RyZXRjaDogXCJhc3BlY3RGaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9jKFwiTGFiZWxcIiwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbDogXCIwXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93OiBcIjFcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogXCIxMlwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcIiM1MjUxNTFcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0OiBcIlB1bHNhL1ZvdWNoZXJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0QWxpZ25tZW50OiBcImNlbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX2MoXCJMYWJlbFwiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sOiBcIjFcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3c6IFwiMVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcIjEyXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwiIzUyNTE1MVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHQ6IFwiUGFrZXQgRGF0YVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHRBbGlnbm1lbnQ6IFwiY2VudGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfYyhcIkxhYmVsXCIsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2w6IFwiMlwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvdzogXCIxXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMTJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCIjNTI1MTUxXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGV4dDogXCJQTE4vVG9rZW5cIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0QWxpZ25tZW50OiBcImNlbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX2MoXCJMYWJlbFwiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sOiBcIjNcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3c6IFwiMVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcIjEyXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwiIzUyNTE1MVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHQ6IFwiUGFzY2EgQmF5YXJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0QWxpZ25tZW50OiBcImNlbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX2MoXCJJbWFnZVwiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjOiBcIn4vaW1hZ2VzL2Zvb2QucG5nXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93OiBcIjJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2w6IFwiMFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cmV0Y2g6IFwiYXNwZWN0Rml0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfYyhcIkltYWdlXCIsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM6IFwifi9pbWFnZXMvZHJpdmVyLnBuZ1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvdzogXCIyXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sOiBcIjFcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJldGNoOiBcImFzcGVjdEZpdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX2MoXCJJbWFnZVwiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjOiBcIn4vaW1hZ2VzL2dyb3Npci5wbmdcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3c6IFwiMlwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbDogXCIyXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RyZXRjaDogXCJhc3BlY3RGaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9jKFwiSW1hZ2VcIiwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYzogXCJ+L2ltYWdlcy9jYXJnby5wbmdcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3c6IFwiMlwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbDogXCIzXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RyZXRjaDogXCJhc3BlY3RGaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9jKFwiTGFiZWxcIiwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbDogXCIwXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93OiBcIjNcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogXCIxMlwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcIiM1MjUxNTFcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0OiBcIkZvb2RcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0QWxpZ25tZW50OiBcImNlbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX2MoXCJMYWJlbFwiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sOiBcIjFcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3c6IFwiM1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcIjEyXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwiIzUyNTE1MVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHQ6IFwiRHJpdmVyL0t1cmlyXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGV4dEFsaWdubWVudDogXCJjZW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9jKFwiTGFiZWxcIiwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbDogXCIyXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93OiBcIjNcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogXCIxMlwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcIiM1MjUxNTFcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0OiBcIkdyb3NpclwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHRBbGlnbm1lbnQ6IFwiY2VudGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfYyhcIkxhYmVsXCIsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2w6IFwiM1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvdzogXCIzXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMTJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCIjNTI1MTUxXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGV4dDogXCJDYXJnb1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHRBbGlnbm1lbnQ6IFwiY2VudGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJTdGFja0xheW91dFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvdzogXCIzXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBcIjM1JVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmdMZWZ0OiBcIjE1XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZ1JpZ2h0OiBcIjE1XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luVG9wOiBcIjEwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgX2MoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJTY3JvbGxWaWV3XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBhdHRyczogeyBvcmllbnRhdGlvbjogXCJob3Jpem9udGFsXCIgfSB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlN0YWNrTGF5b3V0XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgYXR0cnM6IHsgb3JpZW50YXRpb246IFwiaG9yaXpvbnRhbFwiIH0gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJTdGFja0xheW91dFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfYyhcIkltYWdlXCIsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjOiBcIn4vaW1hZ2VzL2Jpa2VkYXkucG5nXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IFwiMTVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogXCIyNSVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbjogXCIxMFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RyZXRjaDogXCJhc3BlY3RGaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiU3RhY2tMYXlvdXRcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX2MoXCJJbWFnZVwiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYzogXCJ+L2ltYWdlcy9zYW1wYWguanBnXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IFwiMTVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogXCIyNSVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbjogXCIxMFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RyZXRjaDogXCJhc3BlY3RGaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiU3RhY2tMYXlvdXRcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX2MoXCJJbWFnZVwiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYzogXCJ+L2ltYWdlcy9hZ2VucHVsc2EuanBnXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IFwiMTVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogXCIyNSVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbjogXCIxMFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RyZXRjaDogXCJhc3BlY3RGaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAxXG4gICAgICAgICAgKSxcbiAgICAgICAgICBfYyhcbiAgICAgICAgICAgIFwiVGFiQ29udGVudEl0ZW1cIixcbiAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgX2MoXG4gICAgICAgICAgICAgICAgXCJTdGFja0xheW91dFwiLFxuICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgICAgICBcIkdyaWRMYXlvdXRcIixcbiAgICAgICAgICAgICAgICAgICAgeyBhdHRyczogeyByb3dzOiBcIiosYXV0bywqLGF1dG8sIGF1dG9cIiB9IH0sXG4gICAgICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgICAgICBfYyhcIkltYWdlXCIsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNyYzpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImh0dHBzOi8vczdkMi5zY2VuZTcuY29tL2lzL2ltYWdlL1RXQ05ld3MvMTAzMV9uY19zdW5ueV93ZWF0aGVyXzItMVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBpb3NPdmVyZmxvd1NhZmVBcmVhOiBcInRydWVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3RyZXRjaDogXCJhc3BlY3RGaWxsXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJvd1NwYW46IFwiNVwiXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgICAgICAgX2MoXG4gICAgICAgICAgICAgICAgICAgICAgICBcIlN0YWNrTGF5b3V0XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICB7IHN0YXRpY0NsYXNzOiBcInRleHQtY2VudGVyXCIsIGF0dHJzOiB7IHJvdzogXCIxXCIgfSB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICAgICAgICBfYyhcIkxhYmVsXCIsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0aWNDbGFzczogXCJoMVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7IHRleHQ6IFwiSmFrYXJ0YVwiLCBjb2xvcjogXCIjZmZmZmZmXCIgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgX2MoXCJMYWJlbFwiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdGljQ2xhc3M6IFwiaDJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyczogeyB0ZXh0OiBcIkNsb3VkeVwiLCBjb2xvcjogXCIjZmZmZmZmXCIgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgX2MoXCJMYWJlbFwiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdGljQ2xhc3M6IFwiaDFcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyczogeyB0ZXh0OiBcIjMzXCIsIGNvbG9yOiBcIiNmZmZmZmZcIiB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICAgICAgMVxuICAgICAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgICAgICAgX2MoXG4gICAgICAgICAgICAgICAgICAgICAgICBcIlNjcm9sbFZpZXdcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgYXR0cnM6IHsgcm93OiBcIjNcIiwgb3JpZW50YXRpb246IFwiaG9yaXpvbnRhbFwiIH0gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgX2MoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJTdGFja0xheW91dFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgYXR0cnM6IHsgb3JpZW50YXRpb246IFwiaG9yaXpvbnRhbFwiIH0gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJTdGFja0xheW91dFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdGljQ2xhc3M6IFwidGV4dC1jZW50ZXJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0aWNTdHlsZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwid2hpdGVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbjogXCIxMFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMTNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9jKFwiTGFiZWxcIiwgeyBhdHRyczogeyB0ZXh0OiBcIk5vd1wiIH0gfSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX2MoXCJJbWFnZVwiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJodHRwczovL2Nkbi5waXhhYmF5LmNvbS9waG90by8yMDE1LzEyLzAzLzE1LzQzL3N1bi0xMDc1MTU0Xzk2MF83MjAucG5nXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogXCIyMFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW46IFwiNVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX2MoXCJMYWJlbFwiLCB7IGF0dHJzOiB7IHRleHQ6IFwiNzlcIiB9IH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJTdGFja0xheW91dFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdGljQ2xhc3M6IFwidGV4dC1jZW50ZXJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0aWNTdHlsZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwid2hpdGVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbjogXCIxMFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMTNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9jKFwiTGFiZWxcIiwgeyBhdHRyczogeyB0ZXh0OiBcIjEwYW1cIiB9IH0pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9jKFwiSW1hZ2VcIiwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiaHR0cHM6Ly9jZG4ucGl4YWJheS5jb20vcGhvdG8vMjAxNS8xMi8wMy8xNS80My9zdW4tMTA3NTE1NF85NjBfNzIwLnBuZ1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IFwiMjBcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiBcIjVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9jKFwiTGFiZWxcIiwgeyBhdHRyczogeyB0ZXh0OiBcIjgxXCIgfSB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAxXG4gICAgICAgICAgKSxcbiAgICAgICAgICBfYyhcbiAgICAgICAgICAgIFwiVGFiQ29udGVudEl0ZW1cIixcbiAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgX2MoXG4gICAgICAgICAgICAgICAgXCJTdGFja0xheW91dFwiLFxuICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgIF9jKFwiTGFiZWxcIiwge1xuICAgICAgICAgICAgICAgICAgICBzdGF0aWNDbGFzczogXCJoMSB0ZXh0LWNlbnRlciBwLXQtMjBcIixcbiAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHsgdGV4dDogXCJCb3R0b20gTmF2IENvbnRlbnQgM1wiIH1cbiAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgICAgX2MoXG4gICAgICAgICAgICAgICAgICAgIFwiTGFiZWxcIixcbiAgICAgICAgICAgICAgICAgICAgeyBzdGF0aWNDbGFzczogXCJmYXNcIiwgYXR0cnM6IHsgdGV4dFdyYXA6IFwidHJ1ZVwiIH0gfSxcbiAgICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJGb3JtYXR0ZWRTdHJpbmdcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgX2MoXCJTcGFuXCIsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyczogeyB0ZXh0OiBcIiYjeGYwNTM7XCIsIGZvbnRBdHRyaWJ1dGVzOiBcIkJvbGRcIiB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICAgICAgMVxuICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgICAgMVxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgMVxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgMVxuICAgICAgICAgICksXG4gICAgICAgICAgX2MoXG4gICAgICAgICAgICBcIlRhYkNvbnRlbnRJdGVtXCIsXG4gICAgICAgICAgICBbXG4gICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgIFwiU3RhY2tMYXlvdXRcIixcbiAgICAgICAgICAgICAgICBbXG4gICAgICAgICAgICAgICAgICBfYyhcIkxhYmVsXCIsIHtcbiAgICAgICAgICAgICAgICAgICAgc3RhdGljQ2xhc3M6IFwiaDEgdGV4dC1jZW50ZXIgcC10LTIwXCIsXG4gICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7IHRleHQ6IFwiQm90dG9tIE5hdiBDb250ZW50IDRcIiB9XG4gICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgMVxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgMVxuICAgICAgICAgICksXG4gICAgICAgICAgX2MoXG4gICAgICAgICAgICBcIlRhYkNvbnRlbnRJdGVtXCIsXG4gICAgICAgICAgICBbXG4gICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgIFwiU3RhY2tMYXlvdXRcIixcbiAgICAgICAgICAgICAgICBbXG4gICAgICAgICAgICAgICAgICBfYyhcIkxhYmVsXCIsIHtcbiAgICAgICAgICAgICAgICAgICAgc3RhdGljQ2xhc3M6IFwiaDEgdGV4dC1jZW50ZXIgcC10LTIwXCIsXG4gICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7IHRleHQ6IFwiQm90dG9tIE5hdiBDb250ZW50IDVcIiB9XG4gICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgMVxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgMVxuICAgICAgICAgIClcbiAgICAgICAgXSxcbiAgICAgICAgMVxuICAgICAgKVxuICAgIF0sXG4gICAgMVxuICApXG59XG52YXIgc3RhdGljUmVuZGVyRm5zID0gW11cbnJlbmRlci5fd2l0aFN0cmlwcGVkID0gdHJ1ZVxuXG5leHBvcnQgeyByZW5kZXIsIHN0YXRpY1JlbmRlckZucyB9Il0sInNvdXJjZVJvb3QiOiIifQ==